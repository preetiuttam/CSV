__author__ = 'niraj.kumar.panda'


import os
import sys
import redis
import logbook


log = logbook.Logger("HerokuRedisManager")


# initiating redis instances
url = os.environ.get('REDIS_URL', 'redis://localhost')
pool = redis.ConnectionPool.from_url(url)
r = redis.Redis(connection_pool=pool)


# parsing command line options
try:
    _file, ops, key1, key2 = sys.argv
except ValueError as e:
    _file, ops, key1 = sys.argv
    key2 = None

log.debug('operation:{};key1:{};key2:{}'.format(ops, key1, key2))


# operations
if ops == 'count' and key2 is None:
	recods = r.smembers(key1)
	log.debug('{} records available in {} set'.format(len(recods), key1))
elif ops == 'delete' and key2 is None:
	r.delete(key1)
	recods = r.smembers(key1)
	log.debug('{} set flushed out;record count is : {}'.format(key1, len(recods)))
elif ops == 'rename' and key2 is not None:
	log.debug('renaming {} set to {} in redis'.format(key1, key2))
	r.rename(key1, key2)
	recods1 = r.smembers(key1)
	recods2 = r.smembers(key2)
	log.debug('{} set count: {};{} set count: {}'.\
		format(key1, len(recods1), key2, len(recods2)))
else:
    log.debug('No operation matched....')