__author__ = 'jan.van.den.broeck'

import os, sys
import datetime
from logbook import Logger
from sqlalchemy import update, func
from sqlalchemy.sql import select, and_, or_, text
from app.tools import get_table, check_is_id
from app.exceptions import BadConfigException, BadInputException

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///:memory:")
SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
SHARING_LEVEL = "Edit"  # Options: None, Read, Edit, All
SHARING_REASON = "Territory_Access__c"


class ShareBatch:
    def __init__(self, engine, metadata, loglevel=0):
        self.engine = engine
        self.metadata = metadata
        self.log = Logger("Share_Batch", level=loglevel)
        self.grace_period = os.environ.get("DAYS_REMOVEAFTER") if os.environ.get("DAYS_REMOVEAFTER") is not None else 7
        self.territory_last_modified = os.environ.get("DAYS_SHARE_AFTER") if os.environ.get("DAYS_SHARE_AFTER") is not None else 1

        # MD
        self.territory = get_table("territory2", metadata, engine, SCHEMA)
        self.territorymodels = get_table("territory2model", metadata, engine, SCHEMA)
        self.object_to_territory = get_table("objectterritory2association", metadata, engine, SCHEMA)
        self.user_to_territory = get_table("userterritory2association", metadata, engine, SCHEMA)
        self.account = get_table("account", metadata, engine, SCHEMA)
        self.account_share = get_table("accountshare", metadata, engine, SCHEMA)
        self.suppliers = get_table("abi_sfa_suppliers__c", metadata, engine, SCHEMA)
        self.account_rel = get_table("abi_sfa_account_relationships__c", metadata, engine, SCHEMA)
        self.group = get_table("group", metadata, engine, SCHEMA)
        self.terr_account_change = get_table("abi_sfa_territoryaccountchange__c", self.metadata, self.engine, SCHEMA)

        # FSM - Visit Execution
        self.visit = get_table("abi_sfa_visit__c", metadata, engine, SCHEMA)
        self.visit_share = get_table("abi_sfa_visit__share", metadata, engine, SCHEMA)
     #   self.activity_group = get_table("abi_sfa_activity_group__c", metadata, engine, SCHEMA)
     #   self.activity_group_share = get_table("abi_sfa_activity_group__share", metadata, engine, SCHEMA)
     #   self.activity = get_table("abi_sfa_activity__c", metadata, engine, SCHEMA)
     #   self.activity_share = get_table("abi_sfa_activity__share", metadata, engine, SCHEMA)

        # FSM - Agreements
     #   self.agreement = get_table("abi_sfa_agreement__c", metadata, engine, SCHEMA)
     #   self.agreement_share = get_table("abi_sfa_agreement__share", metadata, engine, SCHEMA)
     #   self.condition = get_table("abi_sfa_condition__c", metadata, engine, SCHEMA)
     #   self.condition_share = get_table("abi_sfa_condition__share", metadata, engine, SCHEMA)
        self.opportunity = get_table("abi_sfa_opportunity__c", metadata, engine, SCHEMA)
        self.opportunity_share = get_table("abi_sfa_opportunity__share", metadata, engine, SCHEMA)

        # OM
        self.order = get_table("abi_sfa_order__c", metadata, engine, SCHEMA)
        self.order_share = get_table("abi_sfa_order__share", metadata, engine, SCHEMA)

        # Config
        self.object_config = get_table("abi_sfa_object_configuration__c", metadata, engine, SCHEMA)
        self.recordtype = get_table("recordtype", metadata, engine, SCHEMA)
        self.group = get_table("group", metadata, engine, SCHEMA)
        self.groupmember = get_table("groupmember", metadata, engine, SCHEMA)
        self.user = get_table("user", metadata, engine, SCHEMA)

    def run(self, territoryid, insert=True, cleanup=True, modified_only=False):
        """ Execute the sharing calculation for a given territory ID
        :param territoryid: SFDC id of the territory for which the sharing should be processed. Should be 18 characters
        :param insert: whether or not to insert the new shares (set to False for a dummy trial-run)
        :param cleanup: whether or not to remove no-longer-relevant Territory-Access share records
        :return:
        """

        # Variables for easy access
        start = datetime.datetime.now()

        # get associated accounts
        linked_account_ids = self.get_linked_accounts(territoryid)

        # Get sharing config for current territory
        try:
            sharing_scope = self.get_sharing_config(territoryid)
        except BadConfigException as e:
            # Configuration is not OK, we abort
            self.log.error('ABORT: Error processing territory {}: {}'.format(territoryid, e.value))
            return None
        except BadInputException as e:
            # Input is not OK, we abort
            self.log.error('ABORT: Error processing territory {}: {}'.format(territoryid, e.value))
            return None

        # get associated users or groups based on sharing config
        linked_user_ids = self.get_linked_users(territoryid, scope=sharing_scope)

        iterations = len(linked_user_ids)
        current_iteration = 1

        self.log.info('Sharing territory {} with scope {} - {} iterations'.format(territoryid,
                                                                                  sharing_scope,
                                                                                  iterations))

        for user_id in linked_user_ids:
            local_start = datetime.datetime.now()

            if len(linked_account_ids) == 0:
                # If the linked_account_ids is empty, it has no use to continue, nothing would happen
                # Besides, it can be expensive to execute empty "IN" statements
                self.log.info('No Linked accounts for user {}, nothing to share, skipping'.format(user_id))
                continue

            # MD
            # ensure the user actually sees the accounts of the territory
            self.share_accounts(linked_account_ids, user_id, insert=insert)

            # get suppliers + sold to's/payers for the all suppliers/linked accounts (union of set)
            suppliers = self.get_suppliers(linked_account_ids)
            related_accounts = self.get_related_accounts(suppliers | linked_account_ids)
            self.share_accounts(related_accounts, user_id, insert=insert)

            # FSM - Visit Execution
            self.share_object("Visit", self.visit, self.visit_share,
                              'abi_sfa_account__c', territoryid, user_id,
                              insert=insert, modified_only=modified_only)
         #   self.share_object("ActivityGroup", self.activity_group, self.activity_group_share,
         #                     'abi_sfa_account_md__c', territoryid, user_id, insert=insert, modified_only=modified_only)
         #   self.share_object("ActivityLP", self.activity, self.activity_share,
         #                     'abi_sfa_account_lp__c', territoryid, user_id, insert=insert, modified_only=modified_only)
         #   self.share_object("ActivityKPI", self.activity, self.activity_share,
         #                     'abi_sfa_account_kpi__c', territoryid, user_id, insert=insert, modified_only=modified_only)
         #   self.share_object("ActivityToDo", self.activity, self.activity_share,
         #                     'abi_sfa_account_to_do__c', territoryid, user_id, insert=insert, modified_only=modified_only)

            # FSM - Agreements
           # self.share_object("Agreements", self.agreement, self.agreement_share,
           #                   'abi_sfa_account__c', territoryid, user_id, insert=insert, modified_only=modified_only)
           # self.share_object("Condition", self.condition, self.condition_share,
           #                   'abi_sfa_related_account__c', territoryid, user_id, insert=insert, modified_only=modified_only)
            self.share_object("Opportunity", self.opportunity, self.opportunity_share,
                              'abi_sfa_account__c', territoryid, user_id, insert=insert,
                              modified_only=modified_only)

            # OM
            self.share_object("Order", self.order, self.order_share,
                              'abi_sfa_ship_to__c', territoryid, user_id,
                              insert=insert, modified_only=modified_only)

            # Cleanup & logging
            self.log.notice("Finished processing Territory {} User {}; duration {}; iteration {}/{}".format(
                territoryid, user_id, datetime.datetime.now()-local_start, current_iteration, iterations))
            current_iteration += 1

        self.log.notice("Finished processing sharing for Territory {}; duration {}".format(
            territoryid, datetime.datetime.now()-start))

    def share_object(self, description, table, share_table, account_column, territoryid, user, insert=True, modified_only=False):
        """ Shares all objects of a certain type for a given account to a given user
        :param description: Name of the object being shared (for logging purposes)
        :param table: SQLAlchemy table representing the object to be shared
        :param share_table: SQLAlchemy table representing the sharetable of the object to be shared
        :param account_column: name of the column of the table which contains the account id
        :param territoryid: set of accounts to be shared
        :param user: salesforce id of the user
        :param insert: whether to commit the new share records or not
        :return: null
        """

        start = datetime.datetime.now()
        conn = self.engine.connect()

        # get linked records
        j = table.join(self.object_to_territory, self.object_to_territory.c.objectid == table.c[account_column])

        if modified_only:
            last_modified_range = datetime.datetime.now() - datetime.timedelta(days=int(self.territory_last_modified))
            last_modified_range = last_modified_range.strftime("%Y-%m-%d")
            linked_records_q = select([table.c.sfid]).\
                                    select_from(j).where(and_(self.object_to_territory.c.territory2id == territoryid,\
                                                              table.c.lastmodifieddate >= last_modified_range))
        else:
            linked_records_q = select([table.c.sfid]).\
                                    select_from(j).where(self.object_to_territory.c.territory2id == territoryid)

        # get currently shared records for the records of the accounts in the territory
        j = share_table.\
            join(table, table.c.sfid == share_table.c.parentid).\
            join(self.object_to_territory, self.object_to_territory.c.objectid == table.c[account_column])

        shared_records_q = select([share_table.c.parentid]).\
            select_from(j).where(and_(share_table.c.userorgroupid == user,
                                      self.object_to_territory.c.territory2id == territoryid,
                                      or_(share_table.c.rowcause == "Owner",
                                          share_table.c.rowcause == SHARING_REASON)))

        missing_records_q = linked_records_q.except_(shared_records_q)
        new_shares = set([record["sfid"] for record in conn.execute(missing_records_q)])

        self.log.debug('Sharing table {} - new sharing records to User {}: {}'.format(description,
                                                                                      user,
                                                                                      len(new_shares)))

        # Preparing new sharing records
        insert_list = []
        for recordid in new_shares:
            data = dict()
            data["userorgroupid"] = user
            data["parentid"] = recordid
            data["rowcause"] = SHARING_REASON
            data["accesslevel"] = SHARING_LEVEL
            insert_list.append(data)

        # Inserting new sharing records
        if len(insert_list) != 0 and insert is True:
            result = conn.execute(share_table.insert(), insert_list)
            self.log.debug('Inserted {} shares for object {} & user {}'.format(result.rowcount, description, user))

        conn.close()
        self.log.info("Finished processing sharing for object {}; User {}; records {}; duration {}".format(
            description, user, len(new_shares), datetime.datetime.now()-start))


    def get_required_shares_object(self, description, table, share_table, account_column, territoryid, user, insert=True):
        """ Unhares all objects of a certain type for a given account to a given user
        :param description: Name of the object being shared (for logging purposes)
        :param table: SQLAlchemy table representing the object to be shared
        :param share_table: SQLAlchemy table representing the sharetable of the object to be shared
        :param account_column: name of the column of the table which contains the account id
        :param territoryid: set of accounts to be shared
        :param user: salesforce id of the user
        :param insert: whether to commit the new share records or not
        """
        start = datetime.datetime.now()
        conn = self.engine.connect()

        j = table.join(self.object_to_territory, self.object_to_territory.c.objectid == table.c[account_column])
        required_shared_q = select([table.c.sfid]).select_from(j).where(self.object_to_territory.c.territory2id == territoryid)

        required_shared = [ row['sfid'] for row in conn.execute(required_shared_q) ]
        conn.close()

        return required_shared

    def unshare_object(self, description, table, share_table, account_column, accounts, user, territoryid, cleanup=True):

        #  By Jan (incomplete)
                #       get all accounts for which there are share records for this user
        # TODO other than those in the current territory ?
        # TODO watch out for Activity, where there are multiple account columns (or non-issue because only looking at 1 column)
        conn = self.engine.connect()

        j = share_table.join(table, share_table.c.parentid == table.c.sfid)
        qry = select([table.colums[account_column]]).\
            select_from(j).\
            where(and_(share_table.c.userorgroupid == user,
                       share_table.c.rowcause == SHARING_REASON)).\
            group_by(table.colums[account_column])
        accounts_having_share_records = set()
        result = conn.execute(qry)
        for row in result:
            accounts_having_share_records.add(row[account_column])

        # see if there are any accounts that are outside of the current territory based on the accounts in the territory
        accounts_outside_territory = accounts_having_share_records - accounts
        if len(accounts_outside_territory) == 0:
            # The user doesn not have access to any share records belonging to accounts not in his territory
            self.log.info("No {} records outside of those linked to the territory "
                          "shared with user {}".format(description, user))
            return

        # if so, check if they those accounts are in any other territory the user is in (incl M2)

        # We do this by grouping all account-to-territory associations of the accounts_outside_territory on territoryid
        j = self.object_to_territory.\
            join(self.territory, self.object_to_territory.c.territory2id == self.territory.c.sfid ).\
            join(self.territorymodels, self.territory.c.territory2modelid == self.territorymodels.c.sfid)
        qry = select([self.object_to_territory.c.territory2id]).\
            select_from(j).\
            where(and_(self.object_to_territory.c.objectid.in_(accounts_outside_territory),
                       self.object_to_territory.c.isdeleted != True,
                       self.territorymodels.c.state == 'Active')).\
            group_by(self.object_to_territory.c.territory2id)
        result = conn.execute(qry)

        territories_of_accounts_outside_territory = set()
        for row in result:
            territories_of_accounts_outside_territory.add(row["territory2id"])

        territories_w_access = set()
        # Then we check for each territory if the user has access
        for territory in territories_of_accounts_outside_territory:
            sharing_config = self.get_sharing_config(territory)
            linked_users = self.get_linked_users(territory, scope=sharing_config)
            if user in linked_users:
                territories_w_access.add(territory)

        # We deduct the accounts for the territories where the user has access from the accounts outside the territories
        # TODO: and related accounts ?
        accounts_w_access = set()
        for territory in territories_w_access:
            accounts_w_access.add(self.get_linked_accounts(territory)) # todo check set of set

        orphan_accounts = accounts_outside_territory - accounts_w_access

        # set the isdeleted for the share records where the (joined) accountid is in the list
        # and where rowcause = SHARING_REASON

        conn.close()

    def share_accounts(self, related_accounts, user, insert=True):
        """ Ensure all provided accounts are shared with the user
        Shares the provided set/list of related account IDs to the user
        :param related_accounts: list or set of accounts that should be shared with the user
        :param user: userid to whom the accounts should be shared
        :param insert: Whether or not the calculated sharing records should be actually inserted
        :return: null
        """
        start = datetime.datetime.now()
        conn = self.engine.connect()

        groups = self.get_groups(user)
        self.log.debug('share_accounts: User {} is in {} groups'.format(user, len(groups)))
        groups.add(user) # to avoid an OR statement in the query we can add the userid to the set too

        # find the already shared accounts
        qry = select([self.account_share]).where(and_(self.account_share.c.accountaccesslevel.in_(['Edit', 'All']),
                                                      self.account_share.c.accountid.in_(related_accounts),
                                                      self.account_share.c.userorgroupid.in_(groups)))
        result = conn.execute(qry)
        shared_accounts = set()
        for share_record in result:
            shared_accounts.add(share_record['accountid'])

        self.log.debug('share_accounts: There are {} related accounts & '
                       '{} shared accounts'.format(len(related_accounts), len(shared_accounts)))

        # calculate which ones of the provided accounts are not yet shared to the user
        new_shares = related_accounts - shared_accounts

        # Preparing new sharing records
        insert_list = []
        for recordid in new_shares:
            data = dict()
            data["userorgroupid"] = user
            data["accountid"] = recordid
            data["rowcause"] = 'Manual'  # TODO: update
            data["accountaccesslevel"] = SHARING_LEVEL
            data["caseaccesslevel"] = 'None'
            data["opportunityaccesslevel"] = 'None'
            data["contactaccesslevel"] = 'None'
            insert_list.append(data)

        # Inserting new sharing records
        if len(insert_list) != 0 and insert is True:
            result = conn.execute(self.account_share.insert(), insert_list)
            self.log.debug('Inserted {} shares for related accounts & user {}'.format(result.rowcount, user))

        conn.close()
        self.log.info("Finished sharing for object Account; User {}; records {}; duration {}".format(
            user, len(new_shares), datetime.datetime.now()-start))

    def get_linked_users(self, territoryid, scope='Territory'):
        """ Returns the set of user or group ids linked with the (parent) territory
        If the scope is on Territory, it returns all the users of the territory
        If the scope is on ParentTerritory, it returns all the users of the territory +
            the role groups of the users in the parent territory
        :param territoryid: 18-character SFDC ID of the territory to get the users for
        :param scope: String indicating on which level we want to get the linked users/groups
        :return: set of strings of linked users/groups
        """

        conn = self.engine.connect()
        user2ter = self.user_to_territory

        if scope == 'Territory':
            linked_users_q = select([user2ter]).where(user2ter.c.territory2id == territoryid)
            linked_users = conn.execute(linked_users_q)
            return_list = [assoc['userid'] for assoc in linked_users]
            conn.close()
            return set(return_list)

        if scope == 'ParentTerritory':
            # Gets all users + the role groups of the users in the parent territory

            # get the users linked to the current territory
            current_territory_users = self.get_linked_users(territoryid, scope='Territory')
            self.log.debug('Finding linked users (ParentTerritory): '
                           'found {} users linked to current territory'.format(len(current_territory_users)))

            # get the parent territory
            parent_q = select([self.territory]).where(self.territory.c.sfid == territoryid)
            result = conn.execute(parent_q)
            parentterritoryid = result.fetchone()['parentterritory2id']

            # give me all users linked to the parent territory
            parent_territory_users = self.get_linked_users(parentterritoryid, scope='Territory')
            self.log.debug('Finding linked users (ParentTerritory): '
                           'found {} users linked to current parentterritory'.format(len(parent_territory_users)))

            # Find me their roles
            roles_q = select([self.user]).where(self.user.c.sfid.in_(parent_territory_users))
            role_ids = [user['userroleid'] for user in conn.execute(roles_q)]

            self.log.debug('Finding linked users (ParentTerritory): '
                           'found {} roles linked'.format(len(role_ids)))

            # Find me the Role-type groups linked to those roles
            role_groups_q = select([self.group]).where(and_(self.group.c.relatedid.in_(role_ids),
                                                            self.group.c.type == 'RoleAndSubordinates'))
            role_groups = [group['sfid'] for group in conn.execute(role_groups_q)]

            self.log.debug('Finding linked users (ParentTerritory): '
                           'found {} groups linked'.format(len(role_groups)))

            conn.close()
            # Return the union of both sets
            return current_territory_users | set(role_groups)

    def get_sharing_config(self, territoryid):
        """Finds the Custom Sharing scope in the Object configuration for a given territory
        :param territoryid: The territory ID to get the configuration for
        :return: String describing the scope: Territory or ParentTerritory
        """

        # Variables for easy use
        conn = self.engine.connect()

        # Get salesorg & channel from the territory
        self.log.debug('Getting sharing config for territory {}'.format(territoryid))
        qry = select([self.territory]).where(self.territory.c.sfid == territoryid)
        territory = conn.execute(qry).fetchone()

        if territory is None:
            raise BadInputException("Territory with id {} could not be found".format(territoryid))

        salesorg = territory['abi_sfa_salesorg__c']
        channel = territory['abi_sfa_channel__c']

        # Quick Fix for the route_to_market field value mismatch in object-config and territory object
        route_to_market = territory['abi_sfa_m1_type__c'] if territory['abi_sfa_m1_type__c'] != 'BDR-Contract' else 'BDR- Contract'

        self.log.debug('Territory {}: salesorg {} - channel {} - route_to_market {}'.\
                format(territoryid, salesorg, channel, route_to_market))

        j = self.object_config.join(self.recordtype, self.object_config.c.recordtypeid == self.recordtype.c.sfid)
        qry = select([self.object_config]).\
            select_from(j).\
            where(and_(self.object_config.c.abi_sfa_sales_org__c == salesorg,
                       self.object_config.c.abi_sfa_channel__c == channel,
                       self.object_config.c.abi_sfa_route_to_market__c == route_to_market,
                       self.recordtype.c.developername == 'ABI_SFA_Custom_Sharing_Settings'))

        result = conn.execute(qry)
        object_config_list = []
        for record in result:
            object_config_list.append(record['abi_sfa_custom_sharing_rule__c'])

        conn.close()
        self.log.debug('Found {} Object Config record(s) for {} {}'.format(len(object_config_list), salesorg, channel))

        if len(object_config_list) == 1:
            if object_config_list[0] == 'M1 Territory':
                return 'Territory'
            elif object_config_list[0] == 'M2 Territory':
                return 'ParentTerritory'
            else:
                self.log.debug('Value of object config for {} {}: {}'.format(salesorg, channel, object_config_list[0]))
                raise BadConfigException('Custom sharing is not M1 Territory or M2 Territory but {}'.format(object_config_list[0]))
        else:
            raise BadConfigException('No custom sharing object config (or duplicate)')


    def get_suppliers(self, accounts):
        """ Gets all linked suppliers (non-deleted) for a given list or set of account ids
        :param accounts: set of strings of 18-character account ids
        :return: a set of 18-character account ids of the suppliers
        """

        conn = self.engine.connect()

        # Query the database for non-deleted suppliers
        qry = select([self.suppliers]).where(and_(self.suppliers.c.abi_sfa_account_s1__c.in_(accounts),
                                                  self.suppliers.c.isdeleted != True))
        suppliers = conn.execute(qry) # returns a cursor
        supplier_ids = set([row['abi_sfa_supplier__c'] for row in suppliers]) # Loop over cursor & add ids to the set

        # Return the set of supplier ids
        self.log.debug('Found {} supplier relationships for the given account list'.format(len(supplier_ids)))

        conn.close()
        return supplier_ids

    def get_related_accounts(self, ship_tos):
        """ Gets all Sold To, Payer and Bill To accounts related to a given list or set of Ship To's
        :param ship_tos: set of 18-character IDs of Ship To's
        :return: a set of strings with the id of the related Sold To's, Bill To's and Payers
        """

        conn = self.engine.connect()

        # Query all account relationships for the set of ship to's
        qry = select([self.account_rel]).where(and_(self.account_rel.c.abi_sfa_ship_to__c.in_(ship_tos),
                                                    self.account_rel.c.isdeleted != True))
        relationships = conn.execute(qry)

        # Check if it's a valid ID (and not blank, for example) and add it to the set of related accounts
        related_accounts = set()
        for rel in relationships:
            if check_is_id(rel['abi_sfa_sold_to__c']):
                related_accounts.add(rel['abi_sfa_sold_to__c'])
            if check_is_id(rel['abi_sfa_payer__c']):
                related_accounts.add(rel['abi_sfa_payer__c'])
            if check_is_id(rel['abi_sfa_bill_to__c']):
                related_accounts.add(rel['abi_sfa_bill_to__c'])

        self.log.debug('There are {} related sold tos, payers and bill tos'.format(len(related_accounts)))
        conn.close()

        return related_accounts

    def get_groups(self, user):
        """ Get all groups a user belongs to
        :param user: string with the 18-digit user ID
        :return: a set of 18-character IDs
        """

        conn = self.engine.connect()

        # TODO: fix for nested groups
        member_q = select([self.groupmember.c.groupid]).\
            where(self.groupmember.c.userorgroupid == user).\
            group_by(self.groupmember.c.groupid)

        result = conn.execute(member_q)

        groups = set()
        for row in result:
            groups.add(row["groupid"])

        conn.close()

        return groups


    def get_linked_accounts(self, territoryid):
        """ Returns a set of all the accounts linked to a territory
        :param territoryid: string with an 18-digit territory ID
        :return: a set of strings (18-digit IDs) of all accounts
        """

        conn = self.engine.connect()

        object2ter = self.object_to_territory

        linked_accounts_q = select([object2ter]).where(and_(object2ter.c.territory2id == territoryid,
                                                            object2ter.c.isdeleted != True))
        linked_accounts = conn.execute(linked_accounts_q)
        linked_account_ids = set([account['objectid'] for account in linked_accounts])

        conn.close()
        return linked_account_ids

    def get_all_required_accounts(self, conn, territoryids):
        required_shared = set()
        object2ter = self.object_to_territory
        terr2 = self.territory

        for territoryid in territoryids:
            linked_account_ids = self.get_linked_accounts(territoryid)

            # Get sharing config for current territory
            #try:
            #    sharing_scope = self.get_sharing_config(territoryid)

            #    if sharing_scope == 'ParentTerritory':
            #        # then get the list of all the accounts from child territories of the parent territory
                    # add it to linked_account_ids
            #        all_child_accounts_q = select([object2ter]).\
            #                               where(object2ter.c.territory2id.\
            #                               in_(select([terr2.c.sfid]).where(terr2.c.parentterritory2id == territoryid)))
            #        all_child_accounts = [ row['objectid'] for row in conn.execute(all_child_accounts_q) ]
            #        linked_account_ids.union(all_child_accounts)
            #except BadConfigException as e:
                # Configuration is not OK, we abort
            #    self.log.error('ABORT: Error processing territory {}: {}'.format(territoryid, e.value))
            #    continue
            #except BadInputException as e:
                # Input is not OK, we abort
            #    self.log.error('ABORT: Error processing territory {}: {}'.format(territoryid, e.value))
            #    continue


            # ensure the user actually sees the accounts of the territory
            #required_shared.add (linked_account_ids)
            for id in linked_account_ids:
                required_shared.add(id)

            suppliers = self.get_suppliers(linked_account_ids)
            related_accounts = self.get_related_accounts(suppliers | linked_account_ids)

            for account in related_accounts:
                required_shared.add(account)

        return required_shared

    def insert_new_removals(self, conn, new_removals, user, insert=True, _type='Account'):
        # Insert new_removals into ABI_SFA_TerritoryAccountChange__c : refference userid
        insertlist = []
        t_a_change = get_table("abi_sfa_territoryaccountchange__c", self.metadata, self.engine, SCHEMA)
        for account in new_removals:
            valid_till = datetime.date.today() + datetime.timedelta(days=int(self.grace_period))
            valid_till = valid_till.strftime('%Y-%m-%d')
            namedict = { 'abi_sfa_user__c' : user,
                         'abi_sfa_type__c' : _type ,
                         'abi_sfa_recordid__c' : account,
                         'abi_sfa_valid_till__c' : valid_till
                       }
            insertlist.append(namedict)

        self.log.info('Inserting {} newly flagged records of {} type into territoryaccountchange table'.\
                 format(len(insertlist), _type))

        if len(insertlist) != 0 and insert is True:
            result = conn.execute(t_a_change.insert(), insertlist)
            #conn.commit()

    def remove_delete_removals(self, conn, delete_removals, user, _type='Account'):
        # Delete delete_removals permanently from ABI_SFA_TerritoryAccountChange__c : refference separate DS
        deletelist = []
        counter = 0

        for account in delete_removals:
            namedict = {
                         'abi_sfa_recordid__c' : account,
                         'abi_sfa_user__c' : user,
                         'abi_sfa_type__c' : _type
                       }
            deletelist.append(namedict)

        self.log.info('Removing old {} records of {} type from territoryaccountchange table'.\
                 format(len(deletelist), _type))

        # TODO optimze the following code with IN clause as user and type is same for a single call
        for item in deletelist:
            delete_q = text("""DELETE FROM salesforce.abi_sfa_territoryaccountchange__c
                               WHERE abi_sfa_recordid__c = '{}'
                               AND abi_sfa_user__c = '{}'
                               AND abi_sfa_type__c = '{}'""".\
                               format(item['abi_sfa_recordid__c'], item['abi_sfa_user__c'], _type))
            result = conn.execute(delete_q)
            counter += result.rowcount

        self.log.info('{} numbers of {} type records has been removed territoryaccountchange table'.\
                 format(counter, _type))

    def get_existing_removals(self, conn, uid, _type='Account'):
        existing_removals_q = """ SELECT * FROM
                                 salesforce.abi_sfa_territoryaccountchange__c WHERE abi_sfa_user__c = '{}'
                                 AND abi_sfa_type__c = '{}'
                              """.format(uid, _type)
        existing_removals_q = text(existing_removals_q)
        existing_removals = set([ row['abi_sfa_recordid__c'] for row in conn.execute(existing_removals_q) ])

        return existing_removals

    def get_all_M2_accounts(self, conn, all_terrs, required_shared_accounts):
        # Uma: Get the groupid(s) of the user(s) in the parent territory  -> check line 373 to 393, its doing the same there
        role_groups = []
        for territoryid in all_terrs:
            # Gets all users + the role groups of the users in the parent territory
            # get the users linked to the current territory
            current_territory_users = self.get_linked_users(territoryid, scope='Territory')
            self.log.debug('Finding linked users (ParentTerritory): '
                           'found {} users linked to current territory'.format(len(current_territory_users)))

            # get the parent territory
            parent_q = select([self.territory]).where(self.territory.c.sfid == territoryid)
            result = conn.execute(parent_q)
            parentterritoryid = result.fetchone()['parentterritory2id']

            # give me all users linked to the parent territory
            parent_territory_users = self.get_linked_users(parentterritoryid, scope='Territory')
            self.log.debug('Finding linked users (ParentTerritory): '
                           'found {} users linked to current parentterritory'.format(len(parent_territory_users)))

            # Find me their roles
            roles_q = select([self.user]).where(self.user.c.sfid.in_(parent_territory_users))
            role_ids = [user['userroleid'] for user in conn.execute(roles_q)]

            self.log.debug('Finding linked users (ParentTerritory): '
                           'found {} roles linked'.format(len(role_ids)))

            # Find me the Role-type groups linked to those roles
            role_groups_q = select([self.group]).where(and_(self.group.c.relatedid.in_(role_ids),
                                                            self.group.c.type == 'RoleAndSubordinates'))
            groups = [ group['sfid'] for group in conn.execute(role_groups_q) ]

            self.log.debug('Finding linked users (ParentTerritory): '
                           'found {} groups linked'.format(len(groups)))

            # append group ids to list
            groups += list(current_territory_users)
            role_groups += list(set(groups))

        self.log.debug('found {} role groups'.format(len(role_groups)))

        # Get the list of accounts shared with the groupid(s) from the account share table
        accounts_from_given_gids_q = select([self.account_share]).where(self.account_share.c.userorgroupid.in_(role_groups))
        accounts_from_given_gids = [ row['accountid'] for row in conn.execute(accounts_from_given_gids_q) ]
        self.log.debug('{} accounts_from_given_gids found'.format(len(accounts_from_given_gids)))

        # Add it to all_shared - Also add it to a new set called all_group_share
        #all_shared_accs = all_shared_accs | set(accounts_from_given_gids)
        all_group_share = set(accounts_from_given_gids)

        self.log.debug('found {} required_shared_accounts'.format(len(required_shared_accounts)))
        self.log.debug('found {} all_group_share'.format(len(all_group_share)))

        # Create a new set called "All_M2_Shared"
        # All_M2_Shared = all_group_share - required_shared_accounts
        all_m2_shared = all_group_share - required_shared_accounts

        return all_m2_shared


    def get_current_m2_accounts(self, conn, parent_ids):
        object_to_territory = self.object_to_territory
        territory2 = self.territory
        m2_accounts_q = select([object_to_territory.c.objectid]).\
                                                where(object_to_territory.c.territory2id.in_(select([territory2.c.sfid]).\
                                                                where(territory2.c.parentterritory2id.in_(parent_ids))))
        current_m2_accounts = [ row['objectid'] for row in conn.execute(m2_accounts_q) ]

        return set(current_m2_accounts)

    def update_account_removal_flag_for_M2_share(self, conn, sharing_only_accounts, uid):
        if len(sharing_only_accounts) != 0:
                table = self.terr_account_change
                update_q = update(table).\
                                        where(and_(table.c.abi_sfa_user__c == uid,\
                                 table.c.abi_sfa_recordid__c.in_(sharing_only_accounts))).\
                                          values(abi_sfa_account_removal__c=False)
                result = conn.execute(update_q)
                return result.rowcount
        else:
                return 0


    def unshare_accounts(self, uid, insert, cleanup, wholsalers):
        """
            param uid: userid for which unsharing to be done
            param insert: flag to insert or no insert
            param cleanup: flag to remove records or not
            param wholesalers: all wholesalers present in the system
        """
        self.log.info('started unsharing of records for user {}'.format(uid))
        conn = self.engine.connect()
        unshare_start = datetime.datetime.now()

            # Find all the territories
        t_a_change = get_table("abi_sfa_territoryaccountchange__c", self.metadata, self.engine, SCHEMA)

        all_ts_q = """
                      SELECT ut.territory2id
                      FROM salesforce.userterritory2association ut
                      WHERE ut.territory2id IN
                      (SELECT t.sfid FROM salesforce.territory2 t, salesforce.territory2model tm
                      WHERE tm.state = 'Active' AND t.territory2modelid = tm.sfid) AND ut.userid = '{}'
                  """.format(uid)

        all_ts_q = text(all_ts_q)
        result = conn.execute(all_ts_q)

        all_territories = [ row['territory2id'] for row in result ]
        self.log.debug('there are {} active territories found for {} user'.format(len(all_territories), uid))
        required_visits =  set()
        required_orders = set()
        required_opportunities = set()

        # get parentterritory2ids of all_territories received
        parentterritory2id_q = select([self.territory.c.parentterritory2id]).where(self.territory.c.sfid.in_(all_territories))
        parentterritory2ids = [ row['parentterritory2id'] for row in conn.execute(parentterritory2id_q) ]
        self.log.debug('received {} parentterritory2id while unsharing accounts for {} user'.format(len(parentterritory2ids), uid))

        for terr in all_territories:
            required_visits_list = self.get_required_shares_object('Visit', self.visit, self.visit_share,\
                                                               'abi_sfa_account__c', terr, uid, insert=insert)
            for item in required_visits_list:
                required_visits.add(item)

            required_orders_list = self.get_required_shares_object('Order', self.order, self.order_share,\
                                                               'abi_sfa_ship_to__c', terr, uid, insert=insert)
            for item in required_orders_list:
                required_orders.add(item)

            required_opportunities_list = self.get_required_shares_object('Opportunity', self.opportunity, self.opportunity_share,\
                                                              'abi_sfa_account__c', terr, uid, insert=insert)
            for item in required_opportunities_list:
                required_opportunities.add(item)

        self.log.info('Required visits count is {} for user {}'.format(len(required_visits), uid))
        self.log.info('Required orders count is {} for user {}'.format(len(required_orders), uid))
        self.log.info('Required opportunities count is {} for user {} '.format(len(required_opportunities), uid))

            # From Accountshare, get all the accounts which are shared with this user (uid). This will be "All_shared"
        all_shared_acc_q = select([self.account_share.c.accountid]).\
                         where(and_(self.account_share.c.userorgroupid == uid, self.account_share.c.rowcause == 'Manual'))
        all_shared = set([row['accountid'] for row in conn.execute(all_shared_acc_q) ])


        all_shared_visit_q = select([self.visit_share.c.parentid]).\
           where(and_(self.visit_share.c.userorgroupid == uid, self.visit_share.c.rowcause == SHARING_REASON))
        all_shared_visits = set([ row['parentid'] for row in conn.execute(all_shared_visit_q) ])

        all_shared_order_q = select([self.order_share.c.parentid]).\
            where(and_(self.order_share.c.userorgroupid == uid, self.order_share.c.rowcause == SHARING_REASON))
        all_shared_orders = set([ row['parentid'] for row in conn.execute(all_shared_order_q) ])

        all_shared_opportunity_q = select([self.opportunity_share.c.parentid]).\
            where(and_(self.opportunity_share.c.userorgroupid == uid, self.opportunity_share.c.rowcause == SHARING_REASON))
        all_shared_opportunities = set([ row['parentid'] for row in conn.execute(all_shared_opportunity_q) ])

        self.log.info('All shared account count {} for user {}'.format(len(all_shared), uid))
        self.log.info('All shared visit count {} for user {}'.format(len(all_shared_visits), uid))
        self.log.info('All shared order count {} for user {}'.format(len(all_shared_orders), uid))
        self.log.info('All shared opportunity count {} for user {}'.format(len(all_shared_opportunities), uid))

        # for all territories find the required accounts lets say 'required_shared'
        # add all wholesalers to requirer accounts to the required shared accounts to prevent from getting unshared
        required_shared = self.get_all_required_accounts(conn, all_territories)
        self.log.debug('{} required accounts found for {} user'.format(len(required_shared), uid))
        required_shared |= wholsalers
        self.log.debug('Adding {} wholesaler accounts to the required shaared set; \
            Final required share accounts count is:{}; User: {}'.\
                format(len(wholsalers), len(required_shared), uid))
        # Fix done by infosys: Adding related accounts of all wholesalers to required_shared accounts to prevent from getting unshared and TAC records #creation
        wholsalers_related_accounts = self.get_related_accounts(wholsalers)
        required_shared |= wholsalers_related_accounts

        # get current M2 accounts of the parentterritory2ids
        current_m2_accounts = self.get_current_m2_accounts(conn, parentterritory2ids)
        self.log.debug('received {} current_m2_accounts while unsharing accounts for {} user'.format(len(current_m2_accounts), uid))

        # get all M2 shared accounts
        all_m2_shared_accounts = self.get_all_M2_accounts(conn, all_territories, required_shared)
        self.log.debug('{} number of M2 shared accounts for {} user'.format(len(all_m2_shared_accounts), uid))

        # new addition
        unwanted_m2_accounts = all_m2_shared_accounts - current_m2_accounts

        # adding unwanted_m2_accounts with all_shared_accounts
        all_shared = all_shared | unwanted_m2_accounts

            # Find the accountshares which need to be removed : All_shared - Required_shared
        _unshare_accounts = all_shared - required_shared
        _unshare_visits = all_shared_visits - required_visits
        _unshare_orders = all_shared_orders - required_orders
        _unshare_opportunities = all_shared_opportunities - required_opportunities

        self.log.info('Unwanted account objects count {} for user {}'.format(len(_unshare_accounts), uid))
        self.log.info('Unwanted visit objects count {} for user {}'.format(len(_unshare_visits), uid))
        self.log.info('Unwanted order objects count {} for user {}'.format(len(_unshare_orders), uid))
        self.log.info('Unwanted opportunity objects count {} for user {}'.format(len(_unshare_opportunities), uid))

        # Find the new records which have still not been added (flagged) for removal.
        existing_removals = self.get_existing_removals(conn, uid)
        existing_visits = self.get_existing_removals(conn, uid, 'Visit')
        existing_orders = self.get_existing_removals(conn, uid, 'Order')
        existing_opportunities = self.get_existing_removals(conn, uid, 'Opportunity')

        self.log.info('Existing removals account object count is {} for user {}'.format(len(existing_removals), uid))
        self.log.info('Existing removals visit object count is {} for user {}'.format(len(existing_visits), uid))
        self.log.info('Existing removals order object count is {} for user {}'.format(len(existing_orders), uid))
        self.log.info('Existing removals opportunity object count is {} for user {}'.format(len(existing_opportunities), uid))

            # Find the new records which have still not been added (flagged) for removal.
        new_removals = _unshare_accounts - existing_removals
        new_removals_orders = _unshare_orders - existing_orders
        new_removals_visits = _unshare_visits - existing_visits
        new_removals_opportunities = _unshare_opportunities - existing_opportunities

        self.log.info('New removals account object count is {} for user {}'.format(len(new_removals), uid))
        self.log.info('New removals visit object count is {} for user {}'.format(len(new_removals_visits), uid))
        self.log.info('New removals order object count is {} for user {}'.format(len(new_removals_orders), uid))
        self.log.info('New removals opportunity object count is {} for user {}'.format(len(new_removals_opportunities), uid))

        # Find intersection of M2 shared and new_removals accounts
        sharing_only_accounts = set.intersection(new_removals, current_m2_accounts)
        self.log.debug('{} number of sharing_only_accounts i.e M2 accounts while unsharing for {} user'.format(len(sharing_only_accounts), uid))

        # Find the flagged records (ABI_SFA_TerritoryAccountChange__c) which no longer required, should be removed after valid date expires.
        delete_removals = set.intersection(required_shared, existing_removals)
        delete_removals_orders = set.intersection(required_orders, existing_orders)
        delete_removals_opportunities = set.intersection(required_opportunities, existing_opportunities)
        delete_removals_visits = set.intersection(required_visits, existing_visits)

        self.log.info('Delete removals account object count is {} for user {}'.format(len(delete_removals), uid))
        self.log.info('Delete removals visit object count is {} for user {}'.format(len(delete_removals_visits), uid))
        self.log.info('Delete removals order object count is {} for user {}'.format(len(delete_removals_orders), uid))
        self.log.info('Delete removals opportunity object count is {} for user {}'.format(len(delete_removals_opportunities), uid))

            # Inserting new flagged records
        self.insert_new_removals(conn, new_removals, uid, insert)
        self.insert_new_removals(conn, new_removals_orders, uid, insert, 'Order')
        self.insert_new_removals(conn, new_removals_visits, uid, insert, 'Visit')
        self.insert_new_removals(conn, new_removals_opportunities, uid, insert, 'Opportunity')

            # Removing old records
        #self.remove_delete_removals(conn, delete_removals, uid)
        #self.remove_delete_removals(conn, delete_removals_orders, uid, 'Order')
        #self.remove_delete_removals(conn, delete_removals_visits, uid, 'Visit')
        #self.remove_delete_removals(conn, delete_removals_opportunities, uid, 'Opportunity')

        # for all the territoryaccountchange inserted today update the flag ABI_SFA_Account_Removal__c
        # to false for accountid in "sharingonly" and userid = currentuserid
        updated_records_count = self.update_account_removal_flag_for_M2_share(conn, sharing_only_accounts, uid)
        self.log.debug('ABI_SFA_Account_Removal__c flag for {} M2 shared records have been updated while unsharing for {} user'.\
                    format(updated_records_count, uid))

        self.log.notice('Finished unsharing records for user : {}; duration: {}'.\
                format(uid, datetime.datetime.now()-unshare_start))
        conn.close()
