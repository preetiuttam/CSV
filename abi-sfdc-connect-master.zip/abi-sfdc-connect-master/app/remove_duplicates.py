__author__ = 'jan.van.den.broeck'
""" Runnable module to clean up tables that have unsyncable duplicates

This module adds a runnable script to remove the duplicate records from the tables
This script should run daily when there is no processing ongoing
"""

import os
from logging import getLogger

from logbook import Logger, DEBUG, INFO, WARNING, NOTICE
from sqlalchemy import MetaData, create_engine
from sqlalchemy.sql import select, and_, delete, tuple_

from app.exceptions import BadConfigException
from app.tools import get_table

def get_tables(metadata, engine, SCHEMA='salesforce'):
    """ Returns a list of tables that should be cleaned

    :param metadata:
    :param engine:
    :param SCHEMA: defines the
    :return:
    """

    table_list = []

    # MD
    # table_list.append(get_table("accountshare", metadata, engine, SCHEMA))

    # FSM - Visit Execution
    table_list.append(get_table("abi_sfa_visit__share", metadata, engine, SCHEMA))
   # table_list.append(get_table("abi_sfa_activity_group__share", metadata, engine, SCHEMA)) # by ytaneja
   # table_list.append(get_table("abi_sfa_activity__share", metadata, engine, SCHEMA))  # by ytaneja

    # FSM - Agreements
   # table_list.append(get_table("abi_sfa_agreement__share", metadata, engine, SCHEMA))  # by ytaneja
   # table_list.append(get_table("abi_sfa_condition__share", metadata, engine, SCHEMA))  # by ytaneja
    table_list.append(get_table("abi_sfa_opportunity__share", metadata, engine, SCHEMA))

    # OM
    table_list.append(get_table("abi_sfa_order__share", metadata, engine, SCHEMA))

    return table_list

def clean_table(table, engine, log):
    """ Cleans a table of duplicates

    A duplicate is defined as a parentid, userorgroupid combo with rowcause 'Territory_Access__c' with status PENDING
    for which there already exists a parentid, userorgroupid combo with rowcause 'Territory_Access__c'
    with status SYNCED

    Dummy query on which this is based:
    select * from salesforce.abi_sfa_visit__share
    where
    (parentid, userorgroupid) in
        (select parentid, userorgroupid
        from salesforce.abi_sfa_visit__share
        where _hc_lastop = 'SYNCED' and rowcause = 'Territory_Access__c')
    and _hc_lastop = 'PENDING' and rowcause = 'Territory_Access__c'

    :param table: Table object to be cleaned (share-tables only!)
    :param engine: the engine on which to connect
    :param log: the logger to log to
    :return:
    """

    sub_query = select([table.c.parentid, table.c.userorgroupid]).where(and_(table.c._hc_lastop == 'SYNCED',
                                                                             table.c.rowcause == 'Territory_Access__c'))

    query = delete(table).where(and_(table.c._hc_lastop == 'PENDING',
                                     table.c.rowcause == 'Territory_Access__c',
                                     tuple_(table.c.parentid, table.c.userorgroupid).in_(sub_query)))

    log.debug('about to execute cleanup for table {}'.format(table.name))
    conn = engine.connect()
    result = conn.execute(query)
    conn.close()

    log.info("Cleaned table {}: {} records deleted".format(table.name, result.rowcount))

def clean_table_accounts(table, engine, log):
    """ Specific version of clean_table that removes duplicates from the accounthshare table

    :param table: reference to the accountshare table
    :param engine: the engine to connect to
    :param log: the logger to log to
    :return:
    """


    sub_query = select([table.c.accountid, table.c.userorgroupid]).where(and_(table.c._hc_lastop == 'SYNCED',
                                                                              table.c.rowcause == 'Manual'))

    query = delete(table).where(and_(table.c._hc_lastop == 'PENDING',
                                     table.c.rowcause == 'Manual',
                                     tuple_(table.c.accountid, table.c.userorgroupid).in_(sub_query)))
    log.debug('about to execute cleanup for table {}'.format(table.name))
    conn = engine.connect()
    result = conn.execute(query)
    conn.close()

    log.info("Cleaned table {}: {} records deleted".format(table.name, result.rowcount))


if __name__ == '__main__':

    # Database config
    DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
    SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
    DEBUG = os.environ.get('DEBUG', False)

    metadata = MetaData()
    engine = create_engine(DATABASE_URL, echo=DEBUG)

    # Configuring Logging
    LOGLEVEL = os.environ.get('LOGLEVEL', 'INFO')
    loglevels = {'DEBUG': DEBUG, 'INFO': INFO, 'NOTICE': NOTICE, 'WARNING': WARNING}
    log = Logger("RemoveDuplicates", level=loglevels[LOGLEVEL])

    log.info('Started Remove Duplicate script')

    # General sharing table cleanup
    table_list = get_tables(metadata, engine, SCHEMA)
    log.debug('Number of tables retrieved: {}'.format(len(table_list)))

    for table in table_list:
        clean_table(table, engine, log)

    # AccountShare cleanup
    accountshare = get_table("accountshare", metadata, engine, SCHEMA)
    clean_table_accounts(accountshare, engine, log)

    log.info('Finished removing duplicates')

