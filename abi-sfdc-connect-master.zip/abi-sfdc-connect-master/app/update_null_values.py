#!/usr/bin/env python


"""
	This batch updates null valued fields used in account-set criteria to empty i.e('')

	Batch Usage:-
	-------------
	python app/update_null_values.py --help
	
	usage: update_null_values.py [-h] [-r SELF_REPEAT] [-a]

	Null value updator script

	optional arguments:
	  -h, --help            show this help message and exit
	  -r SELF_REPEAT, --self-repeat SELF_REPEAT
	                        Number of self repats to this batch
	  -a, --autocall-next   Whether to auto-call next batch or not?
	
	1. Default Action (This will execute the updates operation once and next batch will not get triggered at the end)
	python app/update_null_values.py

	2. Repeat the update records loop given number of times and exit without calling the next batch
	python app/update_null_values.py --self-repeat <number of times to repeat>

	E.g:- python app/update_null_values.py --self-repeat 2

	3. Repeat the update records loop given number of times and call the next batch after it
	python app/update_null_values.py --self-repeat <number of times to repeat> --autocall-next

	E.g:- python app/update_null_values.py --self-repeat 2 --autocall-next
"""

__author__ = 'niraj.kumar.panda'


import os
import sys
import argparse
import requests
import datetime
import psycopg2
import sqlalchemy
from logbook import Logger, INFO, NOTICE, DEBUG
from sqlalchemy import MetaData, create_engine, update
from sqlalchemy.sql import select, delete, and_, or_, text
from app.tools import *
from app.reload_tables import *


# Fetching Heroku Environment variable values
DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
DEBUG = os.environ.get('DEBUG', False)


# Initiating global logging instance
log = Logger("UpdateNullValues")


def get_parsed_arguments_list():
	"""
		Parse command line arguments and provide parse arguments tuple
	"""
	parser = argparse.ArgumentParser(description='Null value updator script')
	parser.add_argument('-r',
						'--self-repeat', 
						help='Number of self repats to this batch', 
						required=False,
						type=int,
						default=1
					   )
	parser.add_argument('-a',
						'--autocall-next',
						 help='Whether to auto-call next batch or not?', 
						 required=False,
						 action='store_true',
						 default=False
					   )

	args = vars(parser.parse_args())

	return args


def get_all_accountset_criteria_fileds(conn, table, table1):
	"""
		This module returns a set of all the fields used in account-set criteria

		param conn: database connection reference
		param table: accountset__c object orm reference
		param table1: account object orm reference
	"""
	all_fields_q = select([table.c.criteriafield__c]).\
					where(and_(table.c.status__c == 'Active',\
							   table.c.abi_sfa_fixed__c == False,\
							   table.c.criteriafield__c != None))
	result = conn.execute(all_fields_q)

	all_fields = set()

	for record in result:
		current_fileds = [ 
			row.lower() for row in record['criteriafield__c'].split('-!-') 
			if row != None
		]
		all_fields |= set(current_fileds)

	
	columns = table1.c

    # filtering out BOOLEAN and DOUBLE PRECISION type columns
	fields_and_type_dictlist = [ 
		{
			'col' : col.name,
			'type' : col.type
		}
		for col in columns
		if col.name in all_fields and
		not isinstance(col.type, (sqlalchemy.sql.sqltypes.BOOLEAN, 
			sqlalchemy.dialects.postgresql.base.DOUBLE_PRECISION))
	]
	
	log.info('returning {} fields to update'.format(len(fields_and_type_dictlist)))
	log.info('all fields to update are : {}'.format(fields_and_type_dictlist))

	return fields_and_type_dictlist


def manage_heroku_mapping(base_url, connection_id, action, headers):
	url = "{}/api/v3/connections/{}/actions/{}".format(base_url, connection_id, action)
	log.debug('url:{}; headers:{}'.format(url, headers))
	r = requests.post(url, headers=headers)
	log.debug('satus code:{}'.format(r.status_code))
	
	if r.status_code == 202 and action == 'pause':
		log.notice('SFDC<--->HEROKU mapping is paused.Going to update null values to blank.....')
	elif r.status_code == 202 and action == 'resume':
		log.notice('SFDC<--->HEROKU mapping is resumed.Going to trigger accountset association batch')
	else:
		log.notice('Problem while {}ing SFDC<--->HEROKU mapping.Exiting.....'.format(action))
		sys.exit(0)


def main(run_count=1, auto_call=False):
	# Fetching heroku mapping info
	#base_url, auth_key, app_name = get_base_url(), get_auth_key(), get_app_name()
	#connection_id = get_connection_id(base_url, auth_key, app_name)
	#headers = {'Authorization': 'Bearer {}'.format(auth_key)}
	
	# Pause heroku mapping
	# Following code is implemented but commented 
	# as pause/resume is not working due to the enabled bi-directional sync 
	#manage_heroku_mapping(base_url, connection_id, 'pause', headers)

	# Defining required variables
	metadata = MetaData()
	engine = create_engine(DATABASE_URL, echo=DEBUG) 
	connection = engine.connect()

	# getting required table's orm reference
	t_account = get_table("account", metadata, engine, SCHEMA)
	t_accountset = get_table("accountset__c", metadata, engine, SCHEMA)

	# Run the following part as per parameter configured
	for count in range(run_count):
		# SELECT CriteriaField__c FROM AccountSet__c WHERE Status__c = 'Active' AND ABI_SFA_Fixed__c = false and CriteriaField__c != ''
		all_columns = get_all_accountset_criteria_fileds(connection, t_accountset, t_account)

	    # iterate through each column all_columns set
	    # and run the update query on the account table to update fields
	    # set column = '' where column is null
		for index, record in enumerate(all_columns):
			try:
				field_update_q = """
					UPDATE salesforce.account 
					SET {} = NULL
					WHERE {} = '' 
				""".format(record['col'], record['col'])

				log.debug('Processing {}/{} columns;Query is :-  {}'.\
					format(index+1, len(all_columns), record['col']))
				
				query_start = datetime.datetime.now()
				result = connection.execute(field_update_q)
				log.debug('{} records updated while processing the null values for column: {};\
						  type:{};duration: {}'.format(result.rowcount, record['col'],\
						   record['type'], datetime.datetime.now()-query_start))
			except Exception as e:
				log.warn('Exception: {} encountered while updating for {} column;type: {}'.
					format(str(e), record['col'], record['type']))
				continue

	# Close database connection here
	connection.close()

	# Resume heroku mapping
	# Following code is implemented but commented 
	# as pause/resume is not working due to the enabled bi-directional sync
	#manage_heroku_mapping(base_url, connection_id, 'resume', headers)
	
	# After all update operation over trigger the accountset batch if it is asked
	#if auto_call:
		#log.info('All update queries over.Going to trigger the accountset batch')
#os.system('python app/accountset_association_and_deassociation.py -v -f')

		
if __name__ == '__main__':
	args = get_parsed_arguments_list()
	repeat_count, auto_call = args.values()
	main(repeat_count, auto_call=auto_call)
