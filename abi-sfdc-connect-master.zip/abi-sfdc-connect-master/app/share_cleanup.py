#!/usr/bin/env python


__author__ = 'niraj.kumar.panda'


from sqlalchemy import MetaData, create_engine
from sqlalchemy.sql import select, text
from logbook import Logger
import os


log = Logger("ShareCleanUp")


def fetch_all_unique_users_with_less_validity(conn):
    """
        return list of all users for which are having abi_sfa_valid_till__c in past

        :param conn - database connection reference

        :return : list of all distinct users which having abi_sfa_valid_till__c records in past
    """
    fetch_less_valid_q = """
        SELECT DISTINCT abi_sfa_user__c
            FROM salesforce.abi_sfa_territoryaccountchange__c 
        WHERE abi_sfa_valid_till__c < current_date
    """
    fetch_less_valid_q = text(fetch_less_valid_q)
    distinct_users = [ row['abi_sfa_user__c'] for row in conn.execute(fetch_less_valid_q) ]
    
    return distinct_users 


def cleanup_accounts(conn, user):
    """
        cleans up M1 sharing records and abi_sfa_territoryaccountchange__c for the given user from respective table

        :param conn - database connection reference
        :param user - user id for which sharing and unsharing records to be cleaned up

        :return numbers of records removed from sharing table, numbers of records removed from territory-account-change
    """
    select_records_q = """
                          SELECT abi_sfa_recordid__c FROM salesforce.abi_sfa_territoryaccountchange__c 
                          WHERE abi_sfa_user__c = '{}' AND
                          abi_sfa_type__c = '{}' AND
                          abi_sfa_valid_till__c < current_date
                       """.format(user, 'Account')
    
    delete_q = """
                   DELETE FROM salesforce.accountshare WHERE
               userorgroupid = '{}' AND
               rowcause = 'Manual' AND
               accountid IN ({})
               """.format(user, select_records_q)

    result_1 = conn.execute(delete_q) 
    rows_affected_1 = result_1.rowcount

    delete_tac_q = """
               DELETE FROM salesforce.abi_sfa_territoryaccountchange__c
               WHERE abi_sfa_user__c = '{}' AND
               abi_sfa_type__c = '{}' AND
               abi_sfa_recordid__c IN ({})
           """.format(user, 'Account', select_records_q)
    
    result_2 = conn.execute(delete_tac_q) 
    rows_affected_2 = result_2.rowcount

    return rows_affected_1, rows_affected_2


def cleanup_activities(conn, user, table, _type):
    """
        cleans up M1 sharing records and abi_sfa_territoryaccountchange__c for the given user from respective table

        :param conn - database connection reference
        :param user - user id for which sharing and unsharing records to be cleaned up
        :param _type - type of the activities visit/order/opportunity.

        :return numbers of records removed from sharing table, numbers of records removed from territory-account-change
    """
    select_records_q = """
                           SELECT abi_sfa_recordid__c FROM salesforce.abi_sfa_territoryaccountchange__c 
                           WHERE abi_sfa_user__c = '{}' AND
                           abi_sfa_type__c = '{}' AND
                           abi_sfa_valid_till__c < current_date
                       """.format(user, _type)
    
    delete_q = """
                   DELETE FROM {} WHERE
                   userorgroupid = '{}' AND
                   rowcause = 'Territory_Access__c' AND
                   parentid IN ({}) 
               """.format(table, user, select_records_q)

    result_1 = conn.execute(delete_q) 
    rows_affected_1 = result_1.rowcount

    delete_tac_q = """
               DELETE FROM salesforce.abi_sfa_territoryaccountchange__c
               WHERE abi_sfa_user__c = '{}' AND
               abi_sfa_type__c = '{}' AND
               abi_sfa_recordid__c IN ({})
           """.format(user, _type, select_records_q)
    
    result_2 = conn.execute(delete_tac_q) 
    rows_affected_2 = result_2.rowcount

    return rows_affected_1, rows_affected_2


def cleanup_M2_shares(conn):
    """
        cleans up M2 sharing records and abi_sfa_territoryaccountchange__c for the given user from respective table

        :param conn - database connection reference

        :return numbers of records removed from sharing table, numbers of records removed from territory-account-change
    """
    delete_m2_shares_q = """
         DELETE FROM salesforce.accountshare WHERE sfid IN 
         (SELECT abi_sfa_shareid__c FROM salesforce.abi_sfa_territoryaccountchange__c 
         WHERE abi_sfa_valid_till__c < current_date
         AND abi_sfa_shareid__c IS NOT NULL)
    """

    result_1 = conn.execute(delete_m2_shares_q)
    rows_affected_1 = result_1.rowcount

    delete_m2_shares_from_tac_q = """
        DELETE FROM salesforce.abi_sfa_territoryaccountchange__c WHERE 
        abi_sfa_valid_till__c < current_date AND 
        abi_sfa_shareid__c IS NOT  NULL
    """

    result_2 = conn.execute(delete_m2_shares_from_tac_q)
    rows_affected_2 = result_2.rowcount

    return rows_affected_1, rows_affected_2


def main():
    DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
    SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
    DEBUG = os.environ.get('DEBUG', False)
    metadata = MetaData()
    engine = create_engine(DATABASE_URL, echo=DEBUG) 
    connection = engine.connect()
    
    # fetching less valid records 
    users = fetch_all_unique_users_with_less_validity(connection)

    log.debug('{} number of distinct users fetched for which validity is less than today'.format(len(users)))
    
    for user in users:
        rows_affected_1, rows_affected_2 = cleanup_accounts(connection, user)
        log.debug('for user {} {} records from {} and {} records from TAC table'.
                   format(user, rows_affected_1, 'AccountShare', rows_affected_2))
    
    for user in users:
        rows_affected_1, rows_affected_2 = cleanup_activities(connection, user, 'salesforce.abi_sfa_order__share', 'Order')
        log.debug('for user {} {} records from {} and {} records from TAC table'.
                   format(user, rows_affected_1, 'OrderShare', rows_affected_2))
    
    for user in users:
        rows_affected_1, rows_affected_2 = cleanup_activities(connection, user, 'salesforce.abi_sfa_visit__share', 'Visit')
        log.debug('for user {} {} records from {} and {} records from TAC table'.
                   format(user, rows_affected_1, 'VisitShare', rows_affected_2))
    
    for user in users:
        rows_affected_1, rows_affected_2 = cleanup_activities(connection, user, 'salesforce.abi_sfa_opportunity__share', 'Opportunity')
        log.debug('for user {} {} records from {} and {} records from TAC table'.
                   format(user, rows_affected_1, 'OpportunityShare', rows_affected_2))

    # M2 Cleanup
    m2_rows_affected_1, m2_rows_affected_2 = cleanup_M2_shares(connection)
    log.debug('{} M2 share records cleaned up from account_share and {} records cleaned up from abi_sfa_territoryaccountchange__c object'.\
            format(m2_rows_affected_1, m2_rows_affected_2))

    # closing database connection
    log.debug('closing data base connection after completion of all cleanup actions')
    connection.close()


if __name__ == '__main__':
    main()
