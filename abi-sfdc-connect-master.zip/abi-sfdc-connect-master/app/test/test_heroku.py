__author__ = 'niraj.kumar.panda'

""" 
    This a unittest script for heroku batch functionalities.
    This is a proposal only,we need to decide which usecases to be tested.
"""

import os
import unittest
from sqlalchemy import MetaData, create_engine
from sqlalchemy.sql import select, and_, or_, text
from logbook import Logger, INFO, NOTICE, DEBUG
from app.tools import get_table
from app.batch_share import ShareBatch
from app.exceptions import BadConfigException, BadInputException
from app.M2_to_M1_cleanup import perform_M2_M1_share


class HerokuBatchFunctionalTest(unittest.TestCase):
	#def __init__(self):
	#	pass
	def setUp(self):
		"""
			Parent class overridden method to be called to set up test environment
			before running any unittest
		"""
		pass
	def tearDown(self):
		"""
			Parent class overridden method to be called to clean up test environment
			after running any unittest
		"""
		pass
	def test_reload_tables(self):
		pass
	def test_fill_batch_share(self):
		pass
	def test_territory_share(self):
		pass
	def test_fill_batch_unshare(self):
		pass
	def test_M1_unshare(self):
		pass
	def test_M2_unshare(self):
		pass
	def test_share_cleanup(self):
		pass
	def test_M2_to_M1_share_cleanup(self):
		self.assertIsNone(perform_M2_M1_share())
	def test_account_association(self):
		pass
	def test_account_deassociation(self):
		pass
	def test_los_association(self):
		pass
	def test_los_deassociation(self):
		pass
	def test_granular_share(self):
		pass
	def test_modified_territories_share(self):
		pass
	def test_modified_related_records(self):
		pass


if __name__ == '__main__':
	unittest.run()