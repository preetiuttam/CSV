__author__ = 'jan.van.den.broeck'

"""
    Latest Build History
    -----------------------
    Author  : niraj.kumar.panda
    Date    : 4/20/2017
    Changes : Added command line flexibility to process only the modified lowest level territories 
              for imporved performance
"""


import os
import sys
import redis
from logbook import Logger
from datetime import datetime, timedelta
from sqlalchemy.sql import select, and_, or_, text
from sqlalchemy import MetaData, create_engine
from app.tools import get_table


log = Logger("FillBatchShare")
POOL = redis.ConnectionPool.from_url(os.environ.get("REDIS_URL", 'redis://localhost'))
TERR_LAST_MODIFIED = os.environ.get("DAYS_SHARE_AFTER") if os.environ.get("DAYS_SHARE_AFTER") is not None else 1


def get_last_modified_territories(conn, parmas, t_territory2, t_territory2model):
    """
        Provides last modified territories

        param conn: database connection reference
        param params: dict of tables with their orm reference
        param t_territory2: territory2 table orm reference
        param t_territory2model: t_territory2model table orm reference

        Returns set of all latest modified territory ids
    """
    last_modified_range = datetime.now() - timedelta(days=int(TERR_LAST_MODIFIED))
    last_modified_range = last_modified_range.strftime("%Y-%m-%d")
    log.debug('last_modified_range is  :  {}'.format(last_modified_range))
    modified_territories = set()
    
    for table_name, table_ref in parmas.items():
        if table_name == 'territory2':
            get_modified_terrs_q = select([table_ref.c.sfid]).where(table_ref.c.lastmodifieddate >= last_modified_range)
            modified_territories_list = [ row['sfid'] for row in conn.execute(get_modified_terrs_q) ]
        else:
            get_modified_terrs_q = select([table_ref.c.territory2id ]).where(table_ref.c.lastmodifieddate >= last_modified_range)
            modified_territories_list = [ row['territory2id'] for row in conn.execute(get_modified_terrs_q) ]
            
        modified_territories = modified_territories.union(set(modified_territories_list))

    log.debug('found {} latest modified territories(cs+non-cs)'.\
        format(len(modified_territories)))

    # adding code to filter CS territory        
    t_join = t_territory2.join(t_territory2model,\
            and_(t_territory2.c.territory2modelid == t_territory2model.c.sfid,\
            t_territory2.c.territory2typeid != '0M524000000Cam0CAC'))
    cs_territories_q = select([t_territory2.c.sfid]).\
                           select_from(t_join).\
                               where(and_(t_territory2.c.sfid.in_(modified_territories),\
                                   t_territory2model.c.state == 'Active'))
    cs_territories = set([ row['sfid'] for row in conn.execute(cs_territories_q) ])
    #log.debug('cs_territories_q is  :  {}'.format(cs_territories_q))
    #log.debug('cs_territories is  :  {}'.format(cs_territories))
    # modified territories = modified_territories_old  - cs_territories
    modified_territories = modified_territories - cs_territories
    log.debug('found {} latest modified non-cs territories'.format(len(modified_territories)))

    return modified_territories


def fill_batch_share():
    """
    Fills the queue will all territories of the active model that don't have child territories

    :return: None
    """
    DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
    SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
    DEBUG = os.environ.get('DEBUG', False)

    metadata = MetaData()
    engine = create_engine(DATABASE_URL, echo=DEBUG)

    r = redis.Redis(connection_pool=POOL)
    conn = engine.connect()
    
    try:
        flag = sys.argv[1]
    except IndexError as e:
        log.debug('no flag is specified from command line batch trigger. going to process each lowest level territories found')
        flag = None

    log.debug('Starting fill batch share heroku batch.....')
    t_territory2 = get_table("territory2", metadata, engine, SCHEMA)
    t_territory2model = get_table('territory2model', metadata, engine, SCHEMA)
    object_to_territory = get_table("objectterritory2association", metadata, engine, SCHEMA)
    user_to_territory = get_table("userterritory2association", metadata, engine, SCHEMA)

    # get last modified terrorteries
    if flag:
        modified_territories = get_last_modified_territories(conn, 
            {'territory2': t_territory2, 
            'obj_to_terr': object_to_territory, 
            'user_to_terr': user_to_territory
            },
            t_territory2, 
            t_territory2model
        )

    j = t_territory2.join(t_territory2model,\
            and_(t_territory2.c.territory2modelid == t_territory2model.c.sfid,\
            t_territory2.c.territory2typeid == '0M524000000Cam0CAC'))
    all_territories_q = select([t_territory2]).\
        select_from(j).\
        where(t_territory2model.c.state == 'Active')
    #log.debug('all_territories_q is  :  {}'.format(all_territories_q))
    all_territories = set()
    all_territory_parents = set()
    result = conn.execute(all_territories_q)
    for row in result:
        all_territories.add(row['sfid'])
        all_territory_parents.add(row['parentterritory2id'])
    
    if flag == "modified_territories":
        all_territories = modified_territories
        lowest_level_territories = all_territories - all_territory_parents
    else:
        lowest_level_territories = all_territories - all_territory_parents
    #log.debug('lowest_level_territories is  :  {}'.format(lowest_level_territories))
    log.info('found {} territories of which {} parent territories - adding {} to redis'.format(len(all_territories),
                                                                                      len(all_territory_parents),
                                                                                      len(lowest_level_territories)))
    if flag  == "modified_related_records":
        log.debug('modified_related_records flag provided so adding modified in MinimalShareTerritories redis namespace')
        for territory in lowest_level_territories:
            r.sadd('MinimalShareTerritories', territory)
    else:
        log.debug('no modified_related_records flag provided so adding modified in Territory redis namespace')
        for territory in lowest_level_territories:
            r.sadd('Territory', territory)

    log.debug('Done with adding new lowest level territories')
    conn.close()


if __name__ == '__main__':
    fill_batch_share()
