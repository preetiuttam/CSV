#!/usr/bin/env python

__author__ = 'niraj.kumar.panda'


from sqlalchemy import MetaData, create_engine
from sqlalchemy.sql import select, text, and_, or_
from datetime import datetime, timedelta
from logbook import Logger
from app.tools import get_table
import os
import time


log = Logger("GetSalesAreaDates")


def get_account_object_info(conn, table, account):
    query1 = select([table.c.abi_sfa_sales_org__c, table.c.abi_sfa_distribution_channel__c, table.c.abi_sfa_division__c]).\
             where(table.c.sfid == account)
    result = [ {'salesorg' : row['abi_sfa_sales_org__c'], 'distchannel' : row['abi_sfa_distribution_channel__c'], 'division' : row['abi_sfa_division__c']} for row in conn.execute(query1) ]
    
    try:
        sales_org, dist_channel, div = result[0]['salesorg'], result[0]['distchannel'], result[0]['division']
        return sales_org, dist_channel, div
    except IndexError as e:
        return None, None, None


def get_sales_area_info(conn, table, account, sales_org, dist_channel, div):
    query2 = select([table.c.abi_sfa_start_date__c, table.c.abi_sfa_end_date__c]).\
    	     where(and_(\
    	     table.c.abi_sfa_sales_org__c.like(sales_org),\
             table.c.abi_sfa_distribution_channel__c.like(dist_channel),\
             table.c.abi_sfa_division__c.like(div)))
    result = [ {'start' : row['abi_sfa_start_date__c'], 'end' : row['abi_sfa_end_date__c']} for row in conn.execute(query2) ]

    try:
        start_date, end_date = result[0]['start'], result[0]['end']
        return start_date, end_date
    except IndexError as e:
        return None, None


def update_dates_and_syncflag(conn, table, row_dict, start_date, end_date):
    if start_date is None or row_dict['prof'] is None:
        log.debug('as start date is null skipping the entry.... which will be processed once the values will be stored in sales area')
    else:
        # deciding account start date is in past/future/present
        if start_date < datetime.now().date():
            log.debug('start date : {} is in past for account : {} profit center : {} and territory : {}'.\
	        format(start_date, row_dict['account'], row_dict['prof'], row_dict['terr']))
            query = """
	        UPDATE salesforce.abi_sfa_account_profitcenter__c SET
	        abi_sfa_start_date__c = '{}', abi_sfa_end_date__c = '{}', abi_sfa_syncwithsap__c = {} WHERE
		abi_sfa_territory__c = '{}' AND abi_sfa_account__c = '{}' AND
		abi_sfa_profit_center__c = '{}'
	    """.format(datetime.now().strftime("%Y-%m-%d"),\
	              end_date.strftime("%Y-%m-%d"), True,\
		      row_dict['terr'], row_dict['account'], row_dict['prof'])
            result = conn.execute(query)
            log.debug("{} rows updated while processing {} account".format(result.rowcount, row_dict['account']))
        else:
            log.debug('start date : {} is in futute for account : {} profit center : {} and territory : {}'.\
	        format(start_date, row_dict['account'], row_dict['prof'], row_dict['terr']))
            #end_date = datetime.strptime(str(start_date), "%Y-%m-%d") - timedelta(days=1)
            query = """
	        UPDATE salesforce.abi_sfa_account_profitcenter__c SET
	        abi_sfa_start_date__c = '{}', abi_sfa_end_date__c = '{}', abi_sfa_syncwithsap__c = {} WHERE
		abi_sfa_territory__c = '{}' AND abi_sfa_account__c = '{}' AND
		abi_sfa_profit_center__c = '{}'
	    """.format(start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d"), True,\
	               row_dict['terr'], row_dict['account'], row_dict['prof'])
            result = conn.execute(query)
            log.debug("{} rows updated while processing {} account".format(result.rowcount, row_dict['account']))
            
    
def main():
    DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
    SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
    DEBUG = os.environ.get('DEBUG', False)
    metadata = MetaData()
    engine = create_engine(DATABASE_URL, echo=DEBUG) 
    connection = engine.connect()
  
    # declaring required table objects
    t_profit_center = get_table("abi_sfa_account_profitcenter__c", metadata, engine, SCHEMA)
    t_account = get_table("account", metadata, engine, SCHEMA)
    t_salesarea = get_table("abi_sfa_salesarea__c", metadata, engine, SCHEMA)
    
    # for every record select account ids for which start or end date as null
    query1 = select(['*']).\
             where(and_(t_profit_center.c.abi_sfa_start_date__c.is_(None), t_profit_center.c.abi_sfa_end_date__c.is_(None)))
    
    hashlist = [ {'account' : row['abi_sfa_account__c'], 'prof' : row['abi_sfa_profit_center__c'], 'terr' : row['abi_sfa_territory__c']} for row in connection.execute(query1) ]
    
    log.debug('{} number of accounts found where start or end date is null'.format(len(hashlist)))

    for row in hashlist:
        # fetching salesorg, distribution channel, division from account object 
        sales_org, dist_channel, div = get_account_object_info(connection, t_account, row['account'])
		
        if sales_org is None or dist_channel is None or div is None:
            log.debug('no account records found for account {}, hence continuing...'.format(row['account']))
            continue
        log.info('sales org {} -- dist channel {} --- division {} for account {}'.format(sales_org, dist_channel, div, row['account']))
		
        # fetching start and end date from salesarea for given salesorg, distribution channel, division input
        start_date, end_date = get_sales_area_info(connection, t_salesarea, row['account'],  sales_org, dist_channel, div)

        log.info('salesarea for {} account found start date : {} -- end date : {} sales org : {} dist channel : {} division : {}'.\
	   format(row['account'], start_date, end_date, sales_org, dist_channel, div))
		
        # insert start and end date, update syncwithSAP flag in U-A-T-PC object for account
        update_dates_and_syncflag(connection, t_profit_center, row, start_date, end_date)

    log.debug('closing the connection object after processing all null dated accounts')    
    connection.close()


if __name__ == '__main__':
    main()
