#!/usr/bin/env python


__author__ = 'niraj.kumar.panda'


"""
    Batch Usage:-
    -------------
    1) To run the batch for all available territories(default)
    python app/M2_to_M1_cleanup.py

    2) To run for a specific set of territory and parentterritory ids 
    python app/M2_to_M1_cleanup.py -t <18 digit territory id> -p <18 digit parent territory id of the given territoryid>
"""


import os
import sys
import datetime
import argparse
from logbook import Logger, INFO, NOTICE, DEBUG
from sqlalchemy import MetaData, create_engine, update
from sqlalchemy.sql import select, and_, or_, text
from sqlalchemy.dialects import postgresql
from app.tools import get_table
from app.exceptions import BadConfigException, BadInputException
from app.batch_share import ShareBatch


# Fetching Heroku Environment variable values
DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
DEBUG = os.environ.get('DEBUG', False)
INSERT = os.environ.get('DB_INSERT', 'True')
CLEANUP = os.environ.get('DB_CLEANUP', 'False')
LOGLEVEL = os.environ.get('LOGLEVEL', 'INFO')

# Initiating global logging instance
log = Logger("M2-2-M1-ShareCleanUp")
loglevels = {'DEBUG': DEBUG, 'INFO': INFO, 'NOTICE': NOTICE}

# Defining required variables
metadata = MetaData()
engine = create_engine(DATABASE_URL, echo=DEBUG) 
connection = engine.connect()

# initializing instance of batch_share class
batch = ShareBatch(engine=engine, metadata=metadata, loglevel=loglevels[LOGLEVEL])

# getting table references getting used in this batch
t_object_config = get_table("abi_sfa_object_configuration__c", metadata, engine, SCHEMA)
t_territory = get_table("territory2", metadata, engine, SCHEMA)
t_territory2model = get_table('territory2model', metadata, engine, SCHEMA)
t_object2terr_assocn = get_table("objectterritory2association", metadata, engine, SCHEMA)
user_to_territory = get_table("userterritory2association", metadata, engine, SCHEMA)
account_share = get_table("accountshare", metadata, engine, SCHEMA)
t_visit = get_table("abi_sfa_visit__c", metadata, engine, SCHEMA)
visit_share = get_table("abi_sfa_visit__share", metadata, engine, SCHEMA)
t_opportunity = get_table("abi_sfa_opportunity__c", metadata, engine, SCHEMA)
opportunity_share = get_table("abi_sfa_opportunity__share", metadata, engine, SCHEMA)
t_order = get_table("abi_sfa_order__c", metadata, engine, SCHEMA)
order_share = get_table("abi_sfa_order__share", metadata, engine, SCHEMA)
terr_account_change = get_table("abi_sfa_territoryaccountchange__c", metadata, engine, SCHEMA)


def get_parsed_arguments_list():
    """
        Parse command line arguments and provide parse arguments tuple
    """
    parser = argparse.ArgumentParser(description='You are running M2 to M1 share cleanup batch')
    parser.add_argument('-t',
                        '--territory', 
                        help='18 digit territory id to process', 
                        required=False,
                        default='ALL'
                       )
    parser.add_argument('-p',
                        '--parent_territory',
                         help='18 digit parent territory id to process', 
                         required=False,
                         default='ALL'
                       )
    args = vars(parser.parse_args())

    return args


# get parse argument tuple to be used globally
args = get_parsed_arguments_list()


def get_salesorg_and_channel(conn, table):
    """
        Execute query to fetch salesorgs and channels for which ABI_SFA_M2_Sharing_Removal__c is True
 
        param conn : Database connection reference
        param table : table which is to be queried

        return : list of salesorgs and channels
    """
    fetch_salesorg_and_channel_q = select([table.c.sfid, table.c.abi_sfa_sales_org__c, table.c.abi_sfa_channel__c, table.c.abi_sfa_route_to_market__c]).\
                where(and_(table.c.abi_sfa_m2_sharing_removal__c == True))
    sales_orgs, channels, route_to_markets, _ids = [], [], [], []

    for row in conn.execute(fetch_salesorg_and_channel_q):
        sales_orgs.append(row['abi_sfa_sales_org__c'])
        channels.append(row['abi_sfa_channel__c'])
        route_to_markets.append(row['abi_sfa_route_to_market__c'])
        _ids.append(row['sfid'])

    return sales_orgs, channels, route_to_markets, _ids


def get_terr_and_parentterr_dict(conn, table, sales_orgs, channels, route_to_markets):
    """
        Execute query to fetch territory id and parent territory id for given list of salesorgs and channel

        param conn: Database connection reference
        param table : table which is to be queried
        param sales_orgs : list of salesorgs to match in the query
        param channels : list of channels to match in the query

        return : list of matching territory and parent territory ids dictionaries
    """
    # Quick Fix for the route_to_market field value mismatch in object-config and territory object
    route_to_markets = [ i if i != 'BDR- Contract' else 'BDR-Contract' for i in route_to_markets ]

    fetch_territory_q = select([table]).where(and_(table.c.abi_sfa_salesorg__c.in_(sales_orgs),\
                                                   table.c.abi_sfa_channel__c.in_(channels),\
                                                   table.c.abi_sfa_m1_type__c.in_(route_to_markets)))
    #log.debug('Query to run is : {};sales_orgs={};channels={}'.format(str(fetch_territory_q), sales_orgs, channels))
    
    result = conn.execute(fetch_territory_q)
    return_list = []
    
    for row in result:
        new_dict = { 
                   'terr' : row['sfid'], 
                   'parent_terr' : row['parentterritory2id'] 
                   }
        return_list.append(new_dict)
    
    log.debug('returning {} pairs of territory and parent territoryid'.format(len(return_list)))

    return return_list


def get_filtered_territory_and_parentterritory_pair(conn, 
                                                    t_territory2, 
                                                    t_territory2model, 
                                                    terr_parent_dict_list):
    """
        Copy of fill_batch_share method which fetches active territories
        This module to be used for filtering data received from get_terr_and_parentterr_dict method call

        param conn: Database connection reference
        param t_territory2: Object reference for territory 2
        param t_territory2model: Object reference for t_territory2model
        param terr_parent_dict_list: list of dicts i.e [ {'terr' : terrid, 'parent_terr' : parentid} .....]

        return: filtered list of territory and parent territory dict
    """
    j = t_territory2.\
        join(t_territory2model, t_territory2.c.territory2modelid == t_territory2model.c.sfid)
    all_territories_q = select([t_territory2]).\
        select_from(j).\
        where(t_territory2model.c.state == 'Active')

    all_territories = set()
    all_territory_parents = set()
    result = conn.execute(all_territories_q)
    for row in result:
        all_territories.add(row['sfid'])
        all_territory_parents.add(row['parentterritory2id'])

    lowest_level_territories = all_territories - all_territory_parents

    log.info('found {} territories of which {} parent territories - adding {}'.\
            format(len(all_territories), len(all_territory_parents), len(lowest_level_territories)))

    # filter received data
    return_list = []
    for record in terr_parent_dict_list:
        if record['terr'] in lowest_level_territories or record['parent_terr'] in lowest_level_territories:
            return_list.append(record)

    log.info('filtered {} records from territory-parent territory pair'.\
            format(len(terr_parent_dict_list) - len(return_list)))

    return return_list


def get_territory_accounts(conn, table, territoryid):
    """
        Fetch accounts related to a particular territory

        param conn: Database connection reference
        param table : table which is to be queried
        param territory id : territory id for which we need to fetch related accounts

        return : list of matching accounts for the given territory id
    """
    territory_accounts_q = select([table.c.objectid]).where(table.c.territory2id == territoryid)
    territory_accounts = [ row['objectid'] for row in conn.execute(territory_accounts_q) ]

    return territory_accounts


def get_M2_accounts(conn, table1, table2, territoryids, parentid):
    """
        Fetch related M2 accounts for a parent id where territory id is not belongs to the given territory

        param conn: Database connection reference
        param table1 : table which is to be queried
        param table2 : table which is to be queried
        param territoryids : territory ids which to be excluded while fetching related M2 accounts 
                            for the given parent territory
        param parentid : parent territory id for which M2 accounts to be fetched

        return : list of all matching M2 accounts for given parent territory(including) and territory(excluding)
    """
    m2_accounts_q = select([table1.c.objectid]).\
                        where(table1.c.territory2id.in_(select([table2.c.sfid]).\
                            where(and_(table2.c.parentterritory2id == parentid, ~table2.c.sfid.in_(territoryids)))))
    m2_accounts = [ row['objectid'] for row in conn.execute(m2_accounts_q) ]

    return m2_accounts


def get_M2_territories(conn, table, territoryid, parentid):
    """
        Fetch related M2 territories for a parent id where territory id is not belongs to the given territory

        param conn: Database connection reference
        param table : table which is to be queried
        param territoryid : territory id which to be excluded while fetching related M2 territories 
                            for the given parent territory
        param parentid : parent territory id for which M2 accounts to be fetched

        return : list of all matching M2 territories for given parent territory(including) and territory(excluding)
    """
    m2_teritories_q = select([table.c.sfid]).\
                        where(and_(table.c.parentterritory2id == parentid, table.c.sfid != territoryid))
    m2_teritories = [ row['sfid'] for row in conn.execute(m2_teritories_q) ]

    return m2_teritories


def get_M2_group_share_ids(conn, table, group_ids, m1_accounts):
    """
        Fetch share ids for given group or role ids and m2 accounts

        param conn: Database connection reference
        param table : table which is to be queried
        param group_ids : list of all role or group ids
        param m2_accounts : list of all m2 accounts

        return : list of all matching m2 group share ids matching the given group ids and m2 accounts
    """
    # as group_ids list contains both user and group ids
    # so filtering out the user ids from the collection
    group_ids = [ record for record in group_ids if record.startswith('00G') ]
    m2_group_share_ids_q  = select([table.c.sfid]).\
                                where(and_(table.c.userorgroupid.in_(group_ids), table.c.accountid.in_(m1_accounts)))
    m2_group_share_ids = [ row['sfid'] for row in conn.execute(m2_group_share_ids_q) ]

    return m2_group_share_ids


def get_territory_users(conn, table, territoryid):
    """
        Fetch users related to a particular territory

        param conn: Database connection reference
        param table : table which is to be queried
        param territoryid : territory id for which we need to fetch related accounts

        return : list of matching users for the given territory id
    """
    territory_users_q = select([table.c.userid]).\
                            where(table.c.territory2id == territoryid)
    territory_users = [ row['userid'] for row in conn.execute(territory_users_q) ]

    return territory_users


def insert_records(conn, table, accounts, user, _type='Account', share_id=False):
    """
        Inserts given set of accounts/share ids for a given activity type

        param conn: Database connection reference
        param table : table which is to be queried
        param accounts : list of accounts/share ids to be inserted
        param user : user id to be inserted
        param _type : activity type(account/visit/order/opps...). Default is Account.
        param share_id : If True Insert M2 records, else M1 type insertions

        return : Nothing
    """
    insertlist = []
    for account in accounts:
        valid_till = datetime.date.today() + datetime.timedelta(days=int(batch.grace_period))
        valid_till = valid_till.strftime('%Y-%m-%d')
        if share_id:
            namedict = { 
                         'abi_sfa_shareid__c' : account,
                         'abi_sfa_recordid__c' : account,
                         'abi_sfa_valid_till__c' : valid_till 
                       }
        else:
            namedict = { 
                         'abi_sfa_user__c' : user, 
                         'abi_sfa_type__c' : _type ,
                         'abi_sfa_recordid__c' : account,
                         'abi_sfa_valid_till__c' : valid_till 
                       }
        insertlist.append(namedict)

    
    if len(insertlist) != 0:
        log.info('Inserting {} newly flagged records of {} type into territoryaccountchange table'.format(len(insertlist), _type))
        result = conn.execute(table.insert(), insertlist)
    else:
        log.info('Insert-list is found empty.Hence skipping insert operations.....')


def update_m2_share_removal_flag(conn, table, object_config_ids):
    """
        update the ABI_SFA_M2_Sharing_Removal__c records in ABI_SFA_Object_Configuration__c for the processed records(object_config_ids)

        :param conn - Database connection reference
        :param table - ORM object reference for ABI_SFA_Object_Configuration__c object
        :param object_config_ids - ids of abi_sfa_object_configuration__cfor which records need to be updated

    """
    update_q = update(table).where(table.c.sfid.in_(object_config_ids)).values(abi_sfa_m2_sharing_removal__c=False)
    result = conn.execute(update_q)

    log.debug('{} records in abi_sfa_object_configuration__c object been updated after processing the M2 Share cleanup batch'.\
            format(result.rowcount))

        
def get_m1_territories_for_territory_users(conn, table, users):
	"""
	    get all the territories of the users provided as parameter from the userterritory2association table 

	    param conn: database connection reference
	    param table: userterritory2association object reference
	    param users: list of users for which territories need to be queried with

	    return: list of all m1 territories associated with the provided users as parameters
	"""
	m1_territories_q = select([table.c.territory2id]).where(table.c.userid.in_(users))
	m1_territories = [ row['territory2id'] for row in conn.execute(m1_territories_q) ]

	return m1_territories


def main():
    log.info('Going to process M2 to M1 Sharing Cleanup Batch')
    
    # get ABI_SFA_Sales_Org__c, ABI_SFA_Channel__c from ABI_SFA_Object_Configuration__c where ABI_SFA_M2_Sharing_Removal__c = true
    sales_orgs, channels, route_to_markets, sfids = get_salesorg_and_channel(connection, t_object_config)

    log.debug('received {} sales orgs and {} channels from ABI_SFA_Object_Configuration__c for which ABI_SFA_M2_Sharing_Removal__c = true'.\
                     format(len(sales_orgs), len(channels)))

    if len(sales_orgs) == 0 or len(channels) == 0 or len(route_to_markets) == 0:
        log.info('No M2 share records to be cleanedup currently.Hence closing the batch gracefully')
        connection.close()
        sys.exit(0)

    # From territory2 get territoryid, parent territoryid where salesorg and channel match the ones we got from above query
    # we need to add some code to filter out the parent territories from the list we got. check fill_batch_share for this code
    terr_parent_terr_dictlist = get_terr_and_parentterr_dict(connection, t_territory, sales_orgs, channels, route_to_markets)
    terr_parent_terr_dictlist = get_filtered_territory_and_parentterritory_pair(connection, t_territory, t_territory2model, terr_parent_terr_dictlist)
    log.debug('going to process {} territory ids for M2 Share Cleanups'.format(len(terr_parent_terr_dictlist)))

    # checking if any command line options is provided
    if args['territory'] != 'ALL' and args['parent_territory'] != 'ALL':
        log.info('command line options are provided, so getting territory id to process from user.....')
        terr_parent_terr_dictlist = [{'terr' : args['territory'], 'parent_terr' : args['parent_territory']}]

    # process each territory-parent dict received
    for index, record in enumerate(terr_parent_terr_dictlist):
        log.info('Running M2 to M1 unsharing for {}/{} available active territories......'.\
                format(index+1, len(terr_parent_terr_dictlist)))

        # Get the group (role) of the user in the parent territory -> call it group_ids
        group_ids = batch.get_linked_users(record['terr'], scope='ParentTerritory')
        log.debug('{} group ids found while processing M2-->M1 sharing cleanup for {} territory and {} parent territory'.\
                format(len(group_ids), record['terr'], record['parent_terr']))

        # check if there are group ids linked to the parent territory or not
        # if so then abandon the iteration
        if len(group_ids) == 0:
            log.info('M2 to M1 share cleanup processing is abandoned as there are no group ids linked to the parent territory: {} of territory: {}'.\
                format(record['parent_terr'], record['terr']))
            continue
        
        # Get the list of accounts in the territory -> call it territory_accounts
        territory_accounts = get_territory_accounts(connection, t_object2terr_assocn, record['terr'])
        log.debug('{} accounts found while processing M2-->M1 sharing cleanup for {} territory and {} parent territory'.\
                format(len(territory_accounts), record['terr'], record['parent_terr']))

        
        # NEW : Get the list child territories of the parent territory and territory != current territory => M2_Territory
        #m2_teritories = get_M2_territories(connection, t_territory, record['terr'], record['parent_terr'])
        #log.debug('{} m2_territories found while processing M2-->M1 sharing cleanup for {} territory and {} parent territory'.\
        #        format(len(m2_teritories), record['terr'], record['parent_terr']))

        # Get the id from accountshare table where userorgroupid in group_ids and accountid in m2_accounts -> call it m2_group_share_ids
        # also need to check if territory_accounts list is not empty before going to find the m2_group_share_ids
        if len(territory_accounts) != 0:
            m2_group_share_ids = get_M2_group_share_ids(connection, account_share, group_ids, territory_accounts)
            log.debug('{} m2_group_share_ids found while processing M2-->M1 sharing cleanup for {} territory and {} parent territory'.\
                    format(len(m2_group_share_ids), record['terr'], record['parent_terr']))

        # Get all territory users
        territory_users = get_territory_users(connection, user_to_territory, record['terr'])
        log.debug('{} territory_users found while processing M2-->M1 sharing cleanup for {} territory and {} parent territory'.\
                format(len(territory_users), record['terr'], record['parent_terr']))

        # continue the batch processing/loop if the territory_users list is blank
        if len(territory_users) == 0:
        	log.info('M2 to M1 share cleanup processing for the territory {} is abandoned as there are no users linked to this territory'.\
        		format(record['terr']))
        	continue

        # get all the territories of the territory_users from the userterritory2association table as m1_territories
        m1_territories = get_m1_territories_for_territory_users(connection, user_to_territory, territory_users)

        # Get the list of accounts in child territories of the parent territory and territory not = current territory  -> call it m2_accounts
        m2_accounts = get_M2_accounts(connection, t_object2terr_assocn, t_territory, m1_territories, record['parent_terr'])
        log.debug('{} m2_accounts found while processing M2-->M1 sharing cleanup for {} territory and {} parent territory'.\
                format(len(m2_accounts), record['terr'], record['parent_terr']))

        log.info('going to process each territory_users and perform M2-->M1 sharing cleanup operations')

        # iterate in each user
        for user in territory_users:
            # Get the visits related to the account ??
            #m2_visits = batch.get_required_shares_object('visit', t_visit, visit_share, 'abi_sfa_account__c', record['terr'],  user)
            #log.debug('found {} m2 required visits to process;user: {};territory : {}'.\
            #        format(len(m2_visits), user, record['terr']))

            # Get the orders related to the account ??
            #m2_orders = batch.get_required_shares_object('order', t_order, order_share, 'abi_sfa_ship_to__c', record['terr'],  user)
            #log.debug('found {} m2 required orders to process;user: {};territory : {}'.\
            #        format(len(m2_orders), user, record['terr']))

            # Get the opportunities related to the account ??
            #m2_opportunities = batch.get_required_shares_object('Opportunity', t_opportunity, opportunity_share, 'abi_sfa_account__c', record['terr'], user)
            #log.debug('found {} m2 required opportunities to process;user: {};territory : {}'.\
            #        format(len(m2_opportunities), user, record['terr']))

            # insert M2 activities
            insert_records(connection, terr_account_change, m2_accounts, user)   # insert m2_accounts, user, validity_dates
            #insert_records(connection, terr_account_change, m2_visits, user, 'Visit')     # insert m2_visits, user, validity_dates
            #insert_records(connection, terr_account_change, m2_orders, user, 'Order')   # insert m2_orders, user, validity_dates
            #insert_records(connection, terr_account_change, m2_opportunities, user, 'Opportunity')   # insert m2_opportunities, user, validity_dates

        # inserting m2_group_share_ids if m2_group_share_ids list is not empty
        if len(m2_group_share_ids) != 0:
            insert_records(connection, terr_account_change, m2_group_share_ids, None, 'Account', True)

    # update the ABI_SFA_M2_Sharing_Removal__c records in ABI_SFA_Object_Configuration__c for the processed records
    # this update will ensure the processed records wont be picked up in subsequent batch runs
    log.info('Going to update ABI_SFA_M2_Sharing_Removal__c field in ABI_SFA_Object_Configuration__c object')
    update_m2_share_removal_flag(connection, t_object_config, sfids)

    # All M2 --> M1 sharing cleanup operations is complete
    # closing database connection and acknowledge
    log.info('M2 to M1 unsharing batch processing over.')
    connection.close()


if __name__ == '__main__':
    main()