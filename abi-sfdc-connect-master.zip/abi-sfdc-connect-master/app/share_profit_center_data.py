#!/usr/bin/env python


from sqlalchemy import MetaData, create_engine
from sqlalchemy.sql import select, text, and_, or_
from logbook import Logger
from app.tools import get_table
import os

log = Logger("ProfitCenterSharing")


# query to find U-A-T-PC records from profit center object which have end date is null/in future & start_date in past
def get_actual_prof_data(conn):
    query =  """
                 SELECT abi_sfa_user_acc_terr_pc__c FROM salesforce.ab_sfa_account_profitcenter__c
		 WHERE abi_sfa_end_date__c IS NULL OR abi_sfa_end_date__c > current_date AND
		 abi_sfa_Start_Date__c < current_date
	     """
    actual_prof_center_data = set([ row['abi_sfa_user_acc_terr_pc__c'] for row in conn.execute(query) ])

    return actual_prof_center_data


def get_all_users_accounts_and_pfc(conn, tid, metadata, engine, SCHEMA):
    #log.debug('----- fectching accounts, users and profit center for {} territory'.format(tid))
    t_object_to_territory = get_table("objectterritory2association", metadata, engine, SCHEMA)
    t_territory2user = get_table("userterritory2association", metadata, engine, SCHEMA)
    t_territory2 = get_table("territory2", metadata, engine, SCHEMA)

    all_accounts_q = select([t_object_to_territory.c.objectid]).where(t_object_to_territory.c.territory2id == tid) 
    all_users_q = select([t_territory2user.c.userid]).where(t_territory2user.c.territory2id == tid)
    prof_center_q = select([t_territory2.c.abi_sfa_profit_center__c]).where(t_territory2.c.sfid == tid)

    all_accounts = [ row['objectid'] for row in conn.execute(all_accounts_q) ]
    all_users = [ row['userid'] for row in conn.execute(all_users_q) ]
    profit_center = [ row['abi_sfa_profit_center__c'] for row in conn.execute(prof_center_q) ][0]

    return all_accounts, all_users, profit_center


def get_main_and_name_for_territory(conn, tid, metadata, engine, SCHEMA):
    t_territory2 = get_table("territory2", metadata, engine, SCHEMA)
    prof_center_q = select([t_territory2.c.name, t_territory2.c.ab_sfa_main__c]).where(t_territory2.c.sfid == tid)
    result = [ {'main' : row['ab_sfa_main__c'], 'name' : row['name']} for row in conn.execute(prof_center_q) ]
    main, name = result[0]['main'], result[0]['name']

    return main, name


def get_custom_prof_data(conn, metadata, engine, SCHEMA):
    custom_acc_terr_prof_center = set()
    
    t_territory2 = get_table("territory2", metadata, engine, SCHEMA)
    t_territory2model = get_table('territory2model', metadata, engine, SCHEMA)

    j = t_territory2.join(t_territory2model, t_territory2.c.territory2modelid == t_territory2model.c.sfid)
    all_territories_q = select([t_territory2]).\
        select_from(j).\
        where(and_(t_territory2model.c.state == 'Active', t_territory2.c.abi_sfa_profit_center__c != None))

    all_territories = set()
    all_territory_parents = set()
    
    for row in conn.execute(all_territories_q):
        all_territories.add(row['sfid'])
        all_territory_parents.add(row['parentterritory2id'])

    #log.info('all territories are ---- > {}'.format(all_territories))
    #log.info('all territory parents are ---- > {}'.format(all_territory_parents))
    
    lowest_level_territories = all_territories - all_territory_parents
    #log.info('lowest level territories are ---- > {}'.format(lowest_level_territories))
    
    for terr_id in lowest_level_territories:
        accs, users, prof_center = get_all_users_accounts_and_pfc(conn, terr_id, metadata, engine, SCHEMA)
        log.debug('{} accounts, {} users, {} profit center for {} territory'.format(len(accs), len(users), prof_center, terr_id))
        for acc in accs:
            for user in users:
                row_string = str(user) + '::' + str(acc) + '::' + str(terr_id) + '::' + str(prof_center)
                custom_acc_terr_prof_center.add(row_string)

    return custom_acc_terr_prof_center


def insert_new_records(conn, table, records, metadata, engine, SCHEMA):
    insert_list = []
    for record in records:
        user, acc, terr, prof_center = record.split('::')
        main, name = get_main_and_name_for_territory(conn, terr,  metadata, engine, SCHEMA)
        row_dict = {
	    'abi_sfa_syncwithsap__c' : True,
	    'abi_sfa_account__c' : acc,
	    'abi_sfa_main__c' : main,
	    'abi_sfa_user__c' : user,
	    'abi_sfa_user_acc_terr_pc__c' : record,
	    'abi_sfa_profit_center__c' : prof_center,
	    'abi_sfa_territoryid__c' : terr,
	    'abi_sfa_start_date__c' : None,
	    'abi_sfa_end_date__c' : None,
	    'abi_sfa_territory__c' : name 
        }
        insert_list.append(row_dict)			
    
    if len(insert_list) != 0:
        log.debug('going to insert {} number of records in profit center table'.format(len(insert_list)))
        result = conn.execute(table.insert(), insert_list)

def get_account_object_info(conn, table, account):
    query1 = select([table.c.abi_sfa_sales_org__c, table.c.abi_sfa_distribution_channel__c, table.c.abi_sfa_division__c]).\
             where(table.c.sfid == account)
    result = [ {'salesorg' : row['abi_sfa_sales_org__c'], 'distchannel' : row['abi_sfa_distribution_channel__c'], 'division' : row['abi_sfa_division__c']} for row in conn.execute(query1) ]
    
    try:
        sales_org, dist_channel, div = result[0]['salesorg'], result[0]['distchannel'], result[0]['division']
        return sales_org, dist_channel, div
    except IndexError as e:
        return None, None, None

def get_sales_area_info(conn, table, account, sales_org, dist_channel, div):
    query2 = select([table.c.abi_sfa_start_date__c, table.c.abi_sfa_end_date__c]).\
	     where(and_(\
	     table.c.abi_sfa_sales_org__c == sales_org,\
             table.c.abi_sfa_distribution_channel__c == dist_channel,\
             table.c.abi_sfa_division__c == div))
    result = [ {'start' : row['abi_sfa_start_date__c'], 'end' : row['abi_sfa__end_date__c']} for row in conn.execute(query2) ]

    try:
        start_date, end_date = result[0]['start'], result[0]['end']
        return start_date, end_date
    except IndexError as e:
        return None, None


def main():
    DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
    SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
    DEBUG = os.environ.get('DEBUG', False)
    metadata = MetaData()
    engine = create_engine(DATABASE_URL, echo=DEBUG) 
    connection = engine.connect()
   
    # JOB1
    # get records set from account-territory-profitcenter table
    #queried_records = get_actual_prof_data(connection)
    #log.info('queried records count is {}'.format(len(queried_records)))

    # get custom set of all entries of A-T-PC by iterating in all territories
    #custom_prof_center_records = get_custom_prof_data(connection, metadata, engine, SCHEMA)
    #log.info('custom records count is {}'.format(len(custom_prof_center_records)))

    # get intersection of queried and custom records
    #required_records = custom_prof_center_records - queried_records
    #log.info('{} number of required records found'.format(len(required_records)))

    # insert new records
    table = get_table("ab_sfa_account_profitcenter__c", metadata, engine, SCHEMA)
    t_account = get_table("account", metadata, engine, SCHEMA)
    t_salesarea = get_table("abi_sfa_salesarea__c", metadata, engine, SCHEMA)
    #insert_new_records(connection, table, required_records,  metadata, engine, SCHEMA)
    
    # JOB2
    # for every record select account ids for which start or end date as null
    query1 = select([table.c.abi_sfa_account__c]).\
             where(or_(table.c.abi_sfa_start_date__c.is_(None), table.c.abi_sfa_end_date__c.is_(None)))
    
    accounts = [ row['abi_sfa_account__c'] for row in connection.execute(query1) ]
    log.debug('{} number of accounts found where start or end date is null'.format(len(accounts)))

    for account in accounts:
        # fetching salesorg, distribution channel, division from account object 
        sales_org, dist_channel, div = get_account_object_info(connection, t_account, account)
        
        if sales_org is None or dist_channel is None or div is None:
            log.debug('no account records found for account {}, hence continuing...'.format(account))
            continue
        log.info('sales org {} -- dist channel {} --- division {} for account {}'.format(sales_org, dist_channel, div, account))
	
	# fetching start and end date from salesarea for given salesorg, distribution channel, division input
        start_date, end_date = get_sales_area_info(connection, t_salesarea, account,  sales_org, dist_channel, div)

        if start_date is None or end_date is None:
            log.debug('no start and end date record found in salesarea object for {} salesorg {} dist channel {} division and {} account'.\
	        format(sales_org, dist_channel, div, account))
            continue
        log.info('start date {} -- end date {} for accounts info {} sales org {} dist channel {} division'.\
	        format(start_date, end_date, sales_org, dist_channel, div))
        
	# insert start and end date, update syncwithSAP flag in U-A-T-PC object for account
        log.debug('going to insert/update values in U-A-T-PC object')


if __name__ == '__main__':
    main()
