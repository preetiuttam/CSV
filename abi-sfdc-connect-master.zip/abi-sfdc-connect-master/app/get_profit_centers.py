#!/usr/bin/env python

__author__ = 'niraj.kumar.panda'

from sqlalchemy import MetaData, create_engine
from sqlalchemy.sql import select, text, and_, or_
from logbook import Logger
from app.tools import get_table
from datetime import datetime, timedelta
import os


log = Logger("GetProfitCenters")


# finding U::A::T::PC records from profit center object which have end date is null/in future & start_date in past
def get_actual_prof_data(conn):
    query =  """
                 SELECT abi_sfa_user_acc_terr_pc__c FROM salesforce.abi_sfa_account_profitcenter__c
	     """
    actual_prof_center_data = [ row['abi_sfa_user_acc_terr_pc__c'] for row in conn.execute(query) ]

    return actual_prof_center_data


def get_all_users_accounts_and_pfc(conn, tid, metadata, engine, SCHEMA):
    #log.debug('----- fectching accounts, users and profit center for {} territory'.format(tid))
    t_object_to_territory = get_table("objectterritory2association", metadata, engine, SCHEMA)
    t_territory2user = get_table("userterritory2association", metadata, engine, SCHEMA)
    t_territory2 = get_table("territory2", metadata, engine, SCHEMA)

    all_accounts_q = select([t_object_to_territory.c.objectid]).where(t_object_to_territory.c.territory2id == tid) 
    all_users_q = select([t_territory2user.c.userid]).where(t_territory2user.c.territory2id == tid)
    prof_center_q = select([t_territory2.c.abi_sfa_profit_center__c]).where(t_territory2.c.sfid == tid)

    all_accounts = [ row['objectid'] for row in conn.execute(all_accounts_q) ]
    all_users = [ row['userid'] for row in conn.execute(all_users_q) ]
    profit_center = [ row['abi_sfa_profit_center__c'] for row in conn.execute(prof_center_q) ][0]

    return all_accounts, all_users, profit_center


def get_territory_model_string(conn, table, _id):
    terr_parent = ""
    value_str = []

    while terr_parent is not None:
        try:
            query = select([table.c.name, table.c.parentterritory2id]).where(table.c.sfid == _id)
            result = conn.execute(query).fetchone()
            terr_parent, _id = result['name'], result['parentterritory2id']
            value_str.append(terr_parent.split('-')[0].strip())
        except Exception as e:
            terr_parent = None

    name = ""
    
    for item in value_str[::-1]:
        name += item
    
    return name


def get_main_and_name_for_territory(conn, tid, metadata, engine, SCHEMA):
    t_territory2 = get_table("territory2", metadata, engine, SCHEMA)
    prof_center_q = select([t_territory2.c.name, t_territory2.c.ab_sfa_main__c]).where(t_territory2.c.sfid == tid)
    result = [ {'main' : row['ab_sfa_main__c'], 'name' : row['name']} for row in conn.execute(prof_center_q) ]
    main, _name = result[0]['main'], result[0]['name']
    name = get_territory_model_string(conn, t_territory2, tid)

    return main, name


def get_custom_prof_data(conn, metadata, engine, SCHEMA):
    custom_acc_terr_prof_center = [] 
    
    t_territory2 = get_table("territory2", metadata, engine, SCHEMA)
    t_territory2model = get_table('territory2model', metadata, engine, SCHEMA)

    j = t_territory2.join(t_territory2model, t_territory2.c.territory2modelid == t_territory2model.c.sfid)
    all_territories_q = select([t_territory2]).\
        select_from(j).\
        where(and_(t_territory2model.c.state == 'Active', t_territory2.c.abi_sfa_profit_center__c != None))

    all_territories = set()
    all_territory_parents = set()
    
    for row in conn.execute(all_territories_q):
        all_territories.add(row['sfid'])
        all_territory_parents.add(row['parentterritory2id'])

    #log.info('all territories are ---- > {}'.format(all_territories))
    #log.info('all territory parents are ---- > {}'.format(all_territory_parents))
    
    lowest_level_territories = all_territories - all_territory_parents
    #log.info('lowest level territories are ---- > {}'.format(lowest_level_territories))
    
    for terr_id in lowest_level_territories:
        accs, users, prof_center = get_all_users_accounts_and_pfc(conn, terr_id, metadata, engine, SCHEMA)
        #log.debug('{} accounts, {} users, {} profit center for {} territory'.format(len(accs), len(users), prof_center, terr_id))
        for user in users:
            for acc in accs:
                row_string = str(user) + '::' + str(acc) + '::' + str(terr_id) + '::' + str(prof_center)
                custom_acc_terr_prof_center.append(row_string)

    return custom_acc_terr_prof_center


def get_records_with_future_end_date(conn):
    query =  """
                 SELECT abi_sfa_user_acc_terr_pc__c FROM salesforce.abi_sfa_account_profitcenter__c
		 WHERE abi_sfa_end_date__c > current_date
	     """
    future_end_dated_records = [ row['abi_sfa_user_acc_terr_pc__c'] for row in conn.execute(query) ]
    return future_end_dated_records


def update_old_profit_center_records(conn, records, table):
    for record in records:
        user, acc, terr, profit_center_old = record.split('::')
        prof_center_q = select([table.c.abi_sfa_profit_center__c]).where(table.c.sfid == terr)
        profit_center_new = [ row['abi_sfa_profit_center__c'] for row in conn.execute(prof_center_q) ][0]
       
        if profit_center_old != profit_center_new:
            log.info('profit center changed of the territory from old {} to new {}'.format(profit_center_old, profit_center_new))
            end_date = datetime.strptime(str(datetime.now().strftime("%Y-%m-%d")), "%Y-%m-%d") - timedelta(days=1) 
            query = """
                        UPDATE salesforce.abi_sfa_account_profitcenter__c SET abi_sfa_end_date__c = '{}' WHERE
                        abi_sfa_territoryid__c = '{}' AND abi_sfa_account__c = '{}' AND abi_sfa_user__c = '{}'
                    """.format(end_date.strftime("%Y-%m-%d"), terr, acc, user)
            log.debug('update old records query is -----> {}'.format(query))
            result = conn.execute(query)
            log.debug("{} old records have been updated for {}-{}-{} combination".format(result.rowcount, user, acc, terr))


def update_end_dates_for_accounts_users_territory_removal(conn, records):
    end_date = datetime.strptime(str(datetime.now().strftime("%Y-%m-%d")), "%Y-%m-%d") - timedelta(days=1) 
    query = """
        UPDATE salesforce.abi_sfa_account_profitcenter__c SET abi_sfa_end_date__c = '{}' WHERE
        abi_sfa_user_acc_terr_pc__c IN {} 
    """.format(end_date.strftime("%Y-%m-%d"), tuple(records))
    log.debug('update old records query is -----> {}'.format(query))
    result = conn.execute(query)
    log.debug("{} old record's end dates has been modified possible account/user/territory removal from view".format(result.rowcount))


def insert_new_records(conn, table, records, metadata, engine, SCHEMA):
    insert_list = []
    for record in records:
        user, acc, terr, prof_center = record.split('::')
        main, name = get_main_and_name_for_territory(conn, terr,  metadata, engine, SCHEMA)
        row_dict = {
	    'abi_sfa_syncwithsap__c' : False,
	    'abi_sfa_account__c' : acc,
	    'abi_sfa_main__c' : main,
	    'abi_sfa_user__c' : user,
	    'abi_sfa_user_acc_terr_pc__c' : record,
	    'abi_sfa_profit_center__c' : prof_center,
	    'abi_sfa_territoryid__c' : terr,
	    'abi_sfa_start_date__c' : None,
	    'abi_sfa_end_date__c' : None,
	    'abi_sfa_territory__c' : name 
        }
        insert_list.append(row_dict)			
    
    if len(insert_list) != 0:
        log.debug('going to insert {} number of records in profit center table'.format(len(insert_list)))
        result = conn.execute(table.insert(), insert_list)


def main():
    DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
    SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
    DEBUG = os.environ.get('DEBUG', False)
    metadata = MetaData()
    engine = create_engine(DATABASE_URL, echo=DEBUG) 
    connection = engine.connect()
   
    # get records set from account-territory-profitcenter table
    queried_records = list(set(get_actual_prof_data(connection)))
    log.info('queried records count is : {}'.format(len(queried_records)))

    # get custom set of all entries of A-T-PC by iterating in all territories
    custom_prof_center_records = list(set(get_custom_prof_data(connection, metadata, engine, SCHEMA)))
    log.info('custom records count is : {}'.format(len(custom_prof_center_records)))

    # check for old records for which end dates in future and update end date to current date
    # if the profit center is changed for U-A-T combination
    future_end_date_records = get_records_with_future_end_date(connection)
    t_territory = get_table("territory2", metadata, engine, SCHEMA)
    update_old_profit_center_records(connection, future_end_date_records, t_territory)

    # update end dates for account/user/territory removals profit centers to past end date
    records_to_be_updated = [ record for record in future_end_date_records if record not in custom_prof_center_records ]
    if len(records_to_be_updated) != 0:
        update_end_dates_for_accounts_users_territory_removal(connection, records_to_be_updated)

    # insert new records
    if len(queried_records) != 0:
        log.debug('old records are not empty so going to find what chanegs are been happened to U:A:T:PC combinations')
        #symmetric_records = set(custom_prof_center_records) ^ set(queried_records)
        #symmetric_records = set.intersection(set(custom_prof_center_records), set(queried_records))
        required_records = [ record for record in  custom_prof_center_records if record not in queried_records ]
    else:
        log.debug('old records set is  empty so going to insert the custom  values')
        required_records = custom_prof_center_records

    log.info('{} number of required records found'.format(len(required_records)))
    t_profit_center = get_table("abi_sfa_account_profitcenter__c", metadata, engine, SCHEMA)
    insert_new_records(connection, t_profit_center, required_records,  metadata, engine, SCHEMA)

    # closing db connection
    log.debug('closing database connection after fetching all profit centers entries')
    connection.close()
    

if __name__ == '__main__':
    main()
