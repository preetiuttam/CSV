#!/usr/bin/env python


__author__ = 'niraj.kumar.panda'

import os
from logbook import Logger, INFO, NOTICE, DEBUG
from sqlalchemy import MetaData, create_engine, update
from sqlalchemy.sql import select, delete, and_, or_, text

# Fetching Heroku Environment variable values
DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
DEBUG = os.environ.get('DEBUG', False)

# Initiating global logging instance
log = Logger("CreateIndex")

# Defining required variables
metadata = MetaData()
engine = create_engine(DATABASE_URL, echo=DEBUG) 
connection = engine.connect()


ALL_COLUMNS = ['ABI_SFA_Account_Type__c', 
	'ABI_SFA_BDR_Territory_Level_1__c', 
	'ABI_SFA_BDR_Territory_Level_2__c', 
	'ABI_SFA_CH_BDR_Visit_Frequency__c',
	'ABI_SFA_CH_Brand_Priority_1__c',
	'ABI_SFA_CH_Brand_Priority_2__c',
	'ABI_SFA_CH_Cluster__c',
	'ABI_SFA_CH_Eligible_For_Promotion__c',
	'ABI_SFA_CH_Execution_type__c',
	'ABI_SFA_CH_Flag__c',
	'ABI_SFA_CH_KAM__c',
	'ABI_SFA_CH_Last_POCE_Value__c',
	'ABI_SFA_CH_Maturity_Rate__c',
	'ABI_SFA_CH_NAM__c',
	'ABI_SFA_CH_Nielsen_Beer_Cluster__c',
	'ABI_SFA_CH_POC_Banner__c',
	'ABI_SFA_CH_POC_Brand_Ambassador_1__c',
	'ABI_SFA_CH_POC_image__c',
	'ABI_SFA_CH_POC_Owner_Type__c',
	'ABI_SFA_CH_Store_Format__c',
	'ABI_SFA_CH_Tailormade__c',
	'ABI_SFA_CH_Tier__c',
	'ABI_SFA_CH_Total_Store_Surface_m2__c',
	'ABI_SFA_CH_Volume_Potential__c',
	'ABI_SFA_Channel__c',
	'ABI_SFA_Country__c',
	'ABI_SFA_Distribution_Channel__c',
	'ABI_SFA_Indicator_Sales_prospect__c',
	'ABI_SFA_Name_3__c',
	'ABI_SFA_Record_Type_Name__c',
	'ABI_SFA_RL_D_Buying_Group_L2_Type__c',
	'ABI_SFA_RL_Hier_D_Buying_Group__c',
	'ABI_SFA_RL_Main_Supplier_Name__c',
	'ABI_SFA_Route_to_market__c',
	'ABI_SFA_Sales_Org__c',
	'ABI_SFA_Segment__c',
	'ABI_SFA_Status__c',
	'ABI_SFA_Sub_channel__c',
	'ABI_SFA_Sub_segment__c',
	'ABI_SFA_Trade_Program__c',
	'ABI_SFA_Usage__c',
	'ABI_SFA_Won_Lost_POC_status__c',
	'ABI_SFA_Won_Lost_reason_2__c',
	'ABI_SFA_ZIP_Postal_Code__c',
	'Central_Deletion_Flag__c',
	'First_Visit__c',
	'Name',
	'POC_Base__c'
]


def main():
	log.notice('going to create indexs for {} columns.'.format(len(ALL_COLUMNS)))

	for column in ALL_COLUMNS:
		query = "CREATE INDEX heroku_account_{} ON salesforce.account ({})".format(column, column)
		log.info('query is :- {};for column:- {}'.format(query, column))
		result = connection.execute(query)
		log.info('result is :- {};for column:- {}'.format(result, column))

	log.notice('indices created...')



if __name__ == '__main__':
	main()