__author__ = 'jan.van.den.broeck'



import re
import redis
import logbook
from sqlalchemy import Table
from itertools import islice, chain
from collections import OrderedDict
#Testing Deployment.

log = logbook.Logger("AppLogger")


def build_query(fields, operators, values, logical_expression):
    """
        This function is builds a string SQL query from a list of fields, operators,
        values, and a logical expression
    """

    # Splitting fields on separator, exclude empty last part
    fields = fields.split("-!-")[0:-1]
    values = values.split("-!-")[0:-1]
    operators = operators.split("-!-")[0:-1]

    if len(fields) != len(operators) or len(operators) != len(values):
        raise IndexError('Query-building inputs are of different lengths')

    where_clause_dict = dict()

    # need to do the zip here so it isn't exhausted
    for index, (field, operator, value) in enumerate(zip(fields, operators, values)):
        # check if it's a multi-select situation or not
        if ',' in value:
            # It's a multi-select, we should use the list-function of SQL
            value = ["'{}'".format(arg) for arg in value.split(',')]  # Make the values a list, with quotes
            value = ','.join(value)  # make them a comma-separated string
            clause_text = " {} IN ({}) ".format(field, value)
        else:
            # provided operator can be used
            clause_text = " {} {} '{}' ".format(field, operator, value)

        # log.debug('Adding key {} with value {}'.format(str(index + 1), clause_text))
        where_clause_dict[str(index + 1)] = clause_text

    for key, value in where_clause_dict.items():
        # log.debug('key: {} - Value: {}'.format(key, value))
        pass

    replacement_dict = OrderedDict()
    # reversed because replace "1" should not touch "10"
    for i in reversed(range(99)):
        if str(i) in logical_expression:
            replacement_dict[str(i)] = where_clause_dict[str(i)]

    # Replace all at the same instant
    logical_expression = immediate_replace(logical_expression, replacement_dict)

    return logical_expression

def immediate_replace(text, replacement_dict):
    """
        Inline replacement of keys in replacement dict with the values in replacement dict in text
        see http://stackoverflow.com/questions/6116978/python-replace-multiple-strings for more information
    """
    rep = dict((re.escape(k), v) for k, v in replacement_dict.items()) # For safety?
    pattern = re.compile("|".join(rep.keys()))
    text = pattern.sub(lambda m: rep[re.escape(m.group(0))], text) # Magic

    return text

def batch(iterable, size=1):
    """
        Returns an iterator with given batch size, including a small batch at the end if needed
    """
    l = len(iterable)
    for ndx in range(0, l, size):
       yield iterable[ndx:min(ndx+size, l)]


def get_table(name, metadata, engine, schema):
    """
        get sqlalchemy reference of the requested object
    """
    t = Table(name,
              metadata,
              autoload=True,
              autoload_with=engine,
              schema=schema)
    return t


def check_is_id(sfid):
    return sfid is not None and sfid != '' and len(sfid) == 18


def flush_redis(r):
    """
        wrapper function to empty redis
    """
    r.flushall()
    log.debug('app: {} redis database being flushed'.format(app))


def get_redis_accountset(r):
    """
        wrapper function to fetch available accountsets present in redis server
    """
    accountsets = r.smembers('Accountset')
    accountsets = [ item.decode('utf-8') for item in accountsets ]

    return accountsets

def override_accountsets_with_new_ids(r, records, remove_old=False):
    """
        wrapper function to add or overide new accountset ids in redis
    """
    if remove_old:
        r.delete('Accountset')

    for record in records:
        r.sadd('Accountset', record['id'])


def remove_accountset_id_from_redis(r, accountset_id):
    """
        wrapper function to remove given accountset from redis 
    """
    r.srem('Accountset', accountset_id)
