__author__ = 'jan.van.den.broeck'


"""
    Build History
    -------------
    1. Niraj - Added Unsharing method call for Nov-2016 release
    2. Niraj - Added improved and modified only share for July-2017 release
"""

import os
import time
import redis
from sqlalchemy import MetaData, create_engine
from logbook import Logger, INFO, NOTICE, DEBUG
from app.batch_share import ShareBatch


log = Logger("RunBatchShare")
POOL = redis.ConnectionPool.from_url(os.environ.get("REDIS_URL", 'redis://localhost'))


def run_batch_share(engine, metadata, retry=True):
    r = redis.Redis(connection_pool=POOL)
    INSERT = os.environ.get('DB_INSERT', 'True')
    CLEANUP = os.environ.get('DB_CLEANUP', 'False')
    LOGLEVEL = os.environ.get('LOGLEVEL', 'INFO')
    loglevels = {'DEBUG': DEBUG, 'INFO': INFO, 'NOTICE': NOTICE}
    insert = INSERT == 'True'
    cleanup = CLEANUP == 'True'
    batch = ShareBatch(engine=engine, metadata=metadata, loglevel=loglevels[LOGLEVEL])
    
    # Unsharing batch looks for User in redis
    # Sharing batch looks for Territory in redis
    # Sharing batch with modified_related_records looks for Territory in redis
    while True:
        userid = r.spop("Users")        
        
        if userid is not None:
            userid = userid.decode('utf-8')
            log.info('Processing unsharing for User {}'.format(userid))
            wholesalers = r.smembers('Wholesalers')
            wholesalers = [ record.decode('utf-8') for record in wholesalers ]
            batch.unshare_accounts(userid, insert, cleanup, set(wholesalers))
        
        territory_id = r.spop("Territory")

        if territory_id is not None:
            territory_id = territory_id.decode('utf-8')
            log.info('Processing Sharing for Territory {}'.format(territory_id))
            batch.run(territory_id, insert, cleanup)
        
        modified_territory_id = r.spop('MinimalShareTerritories')
        
        if modified_territory_id is not None:
            modified_territory = modified_territory_id.decode('utf-8')
            log.info('Processing sharing for modified related records;Territory:{}'.format(modified_territory))
            batch.run(modified_territory, insert, cleanup, modified_only=True)
        elif (userid is None or territory_id is None or modified_territory_id is None) and retry == True:
            # Users, Territory, MinimalShareTerritories set are empty in redis
            # Hence sleeping without any operation
            log.info('Sleeping User & Territory...')
            time.sleep(10)
        else:
            # Warning: loop shoud not enter to this block normally
            # This block would be excuted when there is possible slow batch processing
            # or two batch processing clashing each other(sharing & unsharing)
            log.info("Users and Territories both are currently available in redis.Continuing.....")
            time.sleep(10)
            continue


if __name__ == '__main__':
    # This batch is part of the Heroku Procfile invocation
    # This keeps the Heorku application running
    # This code starts when we deploy new code to heroku or at every dyno restart event
    DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
    SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
    DEBUG = os.environ.get('DEBUG', False)
    metadata = MetaData()
    engine = create_engine(DATABASE_URL, echo=DEBUG)
    run_batch_share(engine, metadata)