#!/usr/bin/env python


__author__ = 'niraj.kumar.panda'


"""
    Batch Usage:-
    ------------
    You can run batch by either of the 2 available ways

    1. By scheduling with Heroku Scheduler
    2. Using Heroku CLI to run from your command prompt

    Bellow's illustration is for running batch with heroku command line.

	1. To know(help, available command line handles) about the batch:
	heroku run python app/accountset_association_and_deassociation.py --help --app <heroku-app-name>
	
	2. if you want to run for particular account-set ID and LOS dissociation for all LOS IDs
	heroku run python app/accountset_association_and_deassociation.py -a <account-set ID> --app <heroku-app-name>

	3. if you want to run for particular account-set ID and LOS dissociation for a specific LOS ID
	heroku run python app/accountset_association_and_deassociation.py -a <account-set ID> -l <LOS ID> --app <heroku-app-name>

	4. if you want to run complete batch
	heroku run python app/accountset_association_and_deassociation.py --app <heroku-app-name>

	5. if you want to run the batch in developer mode specify '-v' flag end of your command
	   for user mode(default) no need to specify any flag as the batch will run in user mode by default

	6. if you want to flush available accountsets in redis and run entire batch as fresh
    heroku run python app/accountset_association_and_deassociation.py -f --app <heroku-app-name>

	E.g:-
	1. heroku run python app/accountset_association_and_deassociation.py -a a3h9E000000034XQAQ -l a2l24000000Cj1SAAS --app <heroku-app-name>
	2. User mode(default): python app/accountset_association_and_deassociation.py
	3. Developer mode: python app/accountset_association_and_deassociation.py -v
"""


import os
import re
import time
import logging
import datetime
import argparse
from logbook import Logger, DEBUG, INFO, WARNING, NOTICE
from sqlalchemy import MetaData, create_engine, update
from sqlalchemy.sql import select, delete, and_, or_, text
from app.tools import *
from app.reload_tables import *
from app.exceptions import BadConfigException, BadInputException


# Fetching Heroku Environment variable values
DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
DEBUG = os.environ.get('DEBUG', False)
INSERT = os.environ.get('DB_INSERT', 'True')
CLEANUP = os.environ.get('DB_CLEANUP', 'False')
LOGLEVEL = os.environ.get('LOGLEVEL', 'INFO')

# Initiating global logging instance
log = logging.getLogger("AccountSetAssnDessn")

# Defining required variables
metadata = MetaData()
engine = create_engine(DATABASE_URL, echo=DEBUG) 
connection = engine.connect()

# getting table references getting used in this batch
t_account = get_table("account", metadata, engine, SCHEMA)
t_accountset = get_table("accountset__c", metadata, engine, SCHEMA)
t_accountset_assocn = get_table("accountsetassociation__c", metadata, engine, SCHEMA)
t_los = get_table("abi_sfa_level_of_sales__c", metadata, engine, SCHEMA)
t_accounts_with_los = get_table("abi_sfa_accounts_with_los__c", metadata, engine, SCHEMA)
t_accounts_set_with_los = get_table("abi_sfa_account_set_with_los__c", metadata, engine, SCHEMA)
t_object_config = get_table("abi_sfa_object_configuration__c", metadata, engine, SCHEMA)

# initiating redis instances
url = os.environ.get('REDIS_URL', 'redis://localhost')
pool = redis.ConnectionPool.from_url(url)
r = redis.Redis(connection_pool=pool)

# following to be checked before marking heroku processed flag
TABLES_TO_SYNC = ['Account', 'AccountSetAssociation__c']


# create los records data structure picking values from abi_sfa_level_of_sales__c 
# this data structure will be used while associating los with respective fields
los_q = select([t_los])
los_data = connection.execute(los_q)
LOS_DS = dict()
for data in los_data:
	LOS_DS[data['sfid']] = {
		'start' : data['abi_sfa_start_date__c'],
		'end' : data['abi_sfa_end_date__c']
	}


def get_parsed_arguments_list():
	"""
		Parse command line arguments and provide parse arguments tuple
	"""
	parser = argparse.ArgumentParser(description='Account-set Association & Dissociation Batch')
	parser.add_argument('-a',
						'--accountset', 
						help='Account set ID for which batch to be processed(pass ALL to process all account-sets)', 
						required=False,
						default='ALL'
					   )
	parser.add_argument('-l',
						'--los',
						 help='LOS ID to process los Dissociation.Default processes all available LOS', 
						 required=False,
						 default='ALL'
					   )
	parser.add_argument('-v',
						'--verbose',
						required=False,
						help='Turn on developers mode',
						action='store_true',
						default=False
					   )
	parser.add_argument('-f',
						'--flush',
						required=False,
						help='Override values present in redis with the actual accountsets',
						action='store_true',
						default=False
					   )
	args = vars(parser.parse_args())

	return args


# get parse argument tuple to be used globally
args = get_parsed_arguments_list()


# checking whether to run the batch as developer/user
if args['verbose']:
	logging.basicConfig(level=logging.DEBUG)
	log.setLevel(logging.DEBUG)
	log.info('Batch will run in developer mode.All log levels would be traced')
else:
	logging.basicConfig(level=logging.INFO)
	log.setLevel(logging.INFO)
	log.info('Batch will run in user mode.Debug log levels would be suppressed.')


def get_tables_to_sync(connection_id, base_url, auth_key):
    """ 
    	Returns the mappings (tables) that need to be reloaded

    :param connection_id: string with the unique id of the connection
    :param base_url: the base domain name for the API (eg http://connect.heroku.com)
    :param auth_key: string with the users auth key
    :return: a dict with table_name as key and the mapping id as value
    """

    # Example:
    # curl -H "Authorization: Bearer <token>" https://connect.heroku.com/api/v3/connections/<connection_id>?deep=true

    url = '{}/api/v3/connections/{}?deep=true'.format(base_url, connection_id)
    headers = {'Authorization': 'Bearer {}'.format(auth_key)}
    r = requests.get(url, headers=headers)

    if r.status_code != 200:
        raise ConnectionError('could not get the mappings')

    result = json.loads(r.text)
    mappings = result['mappings']
    tables = dict()

    for mapping in mappings:
        if mapping['object_name'] in TABLES_TO_SYNC: #UPPERCASE
            # we don't do diff between counts[sf] and counts[db] because if it's deleted and recreated
            # differently in SFDC, it still needs to sync, so matching counts is not a guarantee
            tables[mapping['object_name']] = mapping['id']

    return tables


def get_active_accountset_ids(conn, table):
	"""
		Fetches accountset id and criteria from accountset object for status is active and fixed is false

		param conn: database connection reference
		param table: accountset object 

		return: list of dictionaries containing accountset_id and criteria
	"""
	fetch_accountset_ids_q = select([table.c.sfid, table.c.accountcriteria__c]).\
								where(and_(table.c.status__c == 'Active', table.c.abi_sfa_fixed__c == False))
	accountset_ids = [ { 
						'id': row['sfid'], 
						'criteria': row['accountcriteria__c'] 
					   } 
	                   for row in conn.execute(fetch_accountset_ids_q) 
	                   if row['accountcriteria__c'] is not None 
	                 ]
	
	# sorting in descending order of the accountset ids
	# to process the most updated accountset id first
	accountset_ids = sorted(accountset_ids, key=lambda k: k['id'], reverse=True) 

	return accountset_ids


def get_accountset_query_from_criteria(criteria):
	"""
		Parse account set criteria and generate equivalent postgre sql query

		param criteria: accountset criteria

		return: equivalent pg query for the given accountset criteria
	"""
	
	log.info('inside get_accountset_query_from_criteria {} accounset id'.format(criteria))
	regex_in = re.compile(' includes', re.IGNORECASE)
	regex_ex = re.compile(' excludes', re.IGNORECASE)
	regex_lk = re.compile(' like ', re.IGNORECASE)
	regex_nl = re.compile('\n')
	#Code to accomodate the null checks while using != operator -- start
	#regex_ne = re.compile(' != NULL ', re.IGNORECASE)
	regex_ne = re.compile(' != ', re.IGNORECASE)
	#code to accomodate the null checks while using != operator -- end
	regex_ne_hashnull = re.compile(" != '#NULL' ", re.IGNORECASE)
	regex_is_empty = re.compile(" = '' ", re.IGNORECASE)
	regex_eq_null = re.compile(' = NULL ', re.IGNORECASE)
	regex_eq_hashnull = re.compile(" = '#NULL' ", re.IGNORECASE)
	regex_eq_nullvar = re.compile(' = NULL ', re.IGNORECASE)
	
	
	criteria = str(criteria)
	log.info('inside after get_accountset_query_from_criteria {} accounset id'.format(criteria))
		 
	criteria = re.sub(regex_in, ' IN', criteria)
	criteria = re.sub(regex_ex, ' NOT IN', criteria)
	criteria = re.sub(regex_lk, ' ILIKE ', criteria)
	criteria = re.sub(regex_nl, '', criteria)
	#modified code to accomodate the null checks while using != operator -- start
	criteria = re.sub(regex_ne, " IS DISTINCT FROM ", criteria)
	criteria = re.sub(regex_ne_hashnull, " IS DISTINCT FROM NULL ", criteria)
	#modified code to accomodate the null checks while using != operator -- end
	criteria = re.sub(regex_eq_null, " IS NULL ", criteria)
	criteria = re.sub(regex_is_empty, " IS NULL ", criteria)
	criteria = re.sub(regex_eq_hashnull, " IS NULL ", criteria)
	criteria = re.sub(regex_eq_nullvar, " IS NULL ", criteria)
	
	log.info('inside after replacement get_accountset_query_from_criteria {} accounset id'.format(criteria))
	query1 = "hi"
	log.info('static string {} printing query 1'.format(query1))
	query = """SELECT sfid FROM salesforce.account WHERE {}""".format(criteria)
	
	query = text(query)
	testquery = query
	log.info('inside query after get_accountset_query_from_criteria {} accounset id'.format(query))
	log.info('inside test query after get_accountset_query_from_criteria {} accounset id'.format(testquery))
	return query


def associate_accounts_and_get_matched_accounts(conn, table1, table2, record):
	"""
		Associate accounts for the current account set against the account set criteria.
		

		param conn: database connection reference
		param table1: account set association object reference
		param table2: account object reference
		param record: dictionary holding account set id and criteria

		Returns matching accounts as per new association and number of accounts associated
	"""
	try:
		# Convert this AccountCriteria__c to Postgress query and get all the Accounts with matching criteria to "AccountsMatchingCriteria"
		log.info('account set criteria before entering the method {}'.format(record['criteria']))

		account_set_criteria_q = get_accountset_query_from_criteria(record['criteria'])
		log.info('account set criteria after returning from method {}'.format(account_set_criteria_q))
		log.info('soql criteria for accountset id: {} is: {}'.format(record['id'], record['criteria']))
		log.info('converted postgre sql query for the accountset: {} criteria is:- {}'.format(record['id'], account_set_criteria_q))
		
		
		
		start = datetime.datetime.now()
		log.info('accountset id: #{};fetching accounts matching with accountset criteria query starts at: {}'.\
				format(record['id'], start))
		result = conn.execute(account_set_criteria_q)

		log.info('accountset id: #{};fetching accounts matching with accountset criteria query ends.Time taken: {}'.\
				format(record['id'], datetime.datetime.now()-start))

		accounts_with_matching_criteria = [ row['sfid'] for row in result ]

		# Get all the accounts in the Account Set Association for the account set  -> call it "AccountsAssociated"
		accounts_associated_q = select([table1.c.account__c]).\
									where(table1.c.accountset__c == record['id'])
		accounts_associated = [ row['account__c'] for row in conn.execute(accounts_associated_q) ]

		log.info('count of accounts matching current criteria:{};count of accounts associated earlier:{};for accountset:{}'.\
				format(len(set(accounts_with_matching_criteria)), len(set(accounts_associated)), record['id']))

		# "NewAccounts" = AccountsMatchingCriteria - AccountsAssociated
		new_accounts = set(accounts_with_matching_criteria) - set(accounts_associated)

		# Insert "NewAccounts" to AccountSetAssociation table with 'ABI_SFA_Manual__c' = false and accountsetid = loop 
		insert_list = []

		for account in new_accounts:
			new_dict = {
				'account__c' : account,
				'abi_sfa_manual__c' : False,
				'accountset__c' : record['id']
			}
			insert_list.append(new_dict)

		if len(insert_list) != 0:
			log.debug('Associating {} newly accounts with account-set id {} in accountsetassociation__c object'.\
				format(len(insert_list), record['id']))
			result = conn.execute(table1.insert(), insert_list)

			# For all the accounts in "NewAccounts" mark the ABI_SFA_IsMarkedForAccountsetAssociation__c = true
			update_q = update(table2).where(table2.c.sfid.in_(new_accounts)).\
							values(abi_sfa_ismarkedforaccountsetassociation__c=True,\
								   abi_sfa_create_condition_association__c=True)
			result = conn.execute(update_q)
			log.debug('{} records updated of account object and ABI_SFA_IsMarkedForAccountsetAssociation__c column;new accounts count is {}'.\
						format(result.rowcount, len(new_accounts)))

			return list(set(accounts_with_matching_criteria)), len(insert_list)
		else:
			log.info('insert_list is empty. hence no accounts to associate for account-set id #{}'.format(record['id']))
			log.info('no account records to update for accountset id #{} as no records get associated'.format(record['id']))
			log.debug('no account records to update for accountset id #{} as no records get associated'.format(record['id']))
			return list(set(accounts_with_matching_criteria)), 0
	except Exception as e:
		log.info('Exception found as : {}'.format(e))
		return False


def deassociate_accounts(conn, table1, table2, record, matched_accounts):
	"""
		Dissociate accounts for the current account set against the current matching accounts
		

		param conn: database connection reference
		param table1: account set association object reference
		param table2: account object reference
		param record: dictionary holding account set id and criteria
		param matched_accounts: list of unique accounts as per current account set criteria

		Returns list of unique accounts which have been dissociated for the current account set
	"""
	# Get list of Accounts Associated to Account Set where ABI_SFA_Manual__c = false -> Call it “NonManualAccountsAssociated”
	non_manual_accounts_for_accountset_q = select([table1.c.account__c]).\
											where(and_(table1.c.accountset__c == record['id'], table1.c.abi_sfa_manual__c == False))
	non_manual_accounts_for_accountset = [ row['account__c'] for row in conn.execute(non_manual_accounts_for_accountset_q) ]

	# "AccountToBeRemoved" = NonManualAccountsAssociated - AccountsMatchingCriteria  
	accounts_to_be_deassociated = set(non_manual_accounts_for_accountset) - set(matched_accounts)

	# For all the accounts in "AccountsToBeRemoved" mark the ABI_SFA_isMarkForAccountsetDeassociation__c = true
	if len(accounts_to_be_deassociated) > 0:
		# Delete the "AccountsToBeRemoved" from AccountSetAssociation table where AccountSetID is matching the loop
		delete_q = delete(table1).where(and_(table1.c.accountset__c == record['id'], table1.c.account__c.in_(accounts_to_be_deassociated)))

		result = conn.execute(delete_q)
		log.debug('{} records dissociated with account set id : {}'.format(result.rowcount, record['id']))

		update_q = update(table2).where(table2.c.sfid.in_(accounts_to_be_deassociated)).\
						values(abi_sfa_ismarkforaccountsetdeassociation__c=True)
		result = conn.execute(update_q)
		log.debug('{} records updated of account object and ABI_SFA_isMarkForAccountsetDeassociation__c column;dissociated accounts count is {}'.\
				format(result.rowcount, len(accounts_to_be_deassociated)))

		# NRL Field to be checked
		return accounts_to_be_deassociated
	else:
		log.debug('no account records to update for {} accountset id as no accounts get dissociated'.format(record['id']))
		return accounts_to_be_deassociated


def associate_los(conn, table1, table2, record, matched_accounts):
	"""
		Associate los for the current account set against the current matching accounts
		

		param conn: database connection reference
		param table1: account_with_los object reference
		param table2: accountset_with_los object reference
		param record: dictionary holding account set id and criteria
		param matched_accounts: list of unique accounts as per current account set criteria

		Returns number of new associated los and list of accountset_los as per current account set
	"""
	# Get the LOS from ABI_SFA_Account_Set_with_LOS__c for the Accounset as "AccountSetLOS"
	# create a combination of LOS you got in first step with Accounts matching criteria 
	accountset_los_q = select([table2.c.abi_sfa_los__c]).where(table2.c.abi_sfa_account_set__c == record['id'])
	accountset_los = [ row['abi_sfa_los__c'] for row in conn.execute(accountset_los_q) ]

	current_account_los_combination = set()
	for los in accountset_los:
	    # generating combinations for los and accounts (as per current account matching criteria)
		for account in matched_accounts:
			current_account_los_combination.add(los + "::" + account)
	
	existing_account_los_combination = set()

    # existing account los combinations would be evaluated if accounts-los records for current accountset id is/are available
    # else all current account-los combinations would be associated as per current batch run
	# query accounts with los and create a combination of Account and LOS
	if len(accountset_los) != 0:
		accounts_for_current_los_q = select([table1.c.abi_sfa_account__c]).where(table1.c.abi_sfa_los__c.in_(accountset_los))
		accounts_for_current_los = [ row['abi_sfa_account__c'] for row in conn.execute(accounts_for_current_los_q) ]

		# generating combinations for los and accounts (as per existing criteria)
		for los in accountset_los:
			for account in accounts_for_current_los:
				existing_account_los_combination.add(los + "::" + account)

	log.debug('{} existing los; {} los as per present criteria for #{} account set'.\
				format(len(existing_account_los_combination), len(current_account_los_combination), record['id']))
	
	# "New-LOS" = AccountSetLOS - ExisitingLOS
	new_account_los_combination = current_account_los_combination - existing_account_los_combination


	# Insert "New LOS" into ABI_SFA_Accounts_with_LOS__c
	account_los_dictlist = []
	
	for combination in new_account_los_combination:
		los, account = combination.split('::')
		account_los_dict = {
				'abi_sfa_account__c' : account,
				'abi_sfa_los__c' : los,
				'abi_sfa_manual__c': False,
				'abi_sfa_valid_from__c' : LOS_DS[los]['start'],
				'abi_sfa_valid_thru__c' : LOS_DS[los]['end']
		}
		account_los_dictlist.append(account_los_dict)
	
	if len(account_los_dictlist) != 0:
		log.debug('Associating {} newly los while processing account-set id #{} in ABI_SFA_Accounts_with_LOS__c object'.\
			format(len(account_los_dictlist), record['id']))
		result = conn.execute(table1.insert(), account_los_dictlist)
		
		return len(account_los_dictlist)
	else:
		log.debug('Associating no newly los while processing account-set id #{} in ABI_SFA_Accounts_with_LOS__c object'.\
			format(record['id']))
		return 0


def deassociate_los(conn, t_los, t_accounts_with_los, t_accounts_set_with_los):
	"""
		performs dissociation business logic after completion of 
		1. accountset association, dissociation 
		2. los association

		:param conn: database object reference
		:param t_los: abi_sfa_level_of_sales__c object
		:param t_accounts_with_los: abi_sfa_accounts_with_los__c object
		:param t_accounts_set_with_los: abi_sfa_account_set_with_los__c object

		return:
	"""
	# fetch los available presently
	get_los_q = select([t_los.c.sfid])
	all_los = set([ row['sfid'] for row in conn.execute(get_los_q) ])
	log.debug('fetched {} los to dessociate'.format(len(all_los)))

	start = datetime.datetime.now()
	log.info('los dissociation for {} los is started at {}'.format(len(all_los), start))

	# check passed parameter to process all LOS or a particular LOS id.
	# los(used in SIT) == "a2l24000000Cj1SAAS"
	if args['los'] != 'ALL':
		all_los = []
		all_los.append(args['los'])
    
    # iterate through each los and perform los dissociation logic
	for los in all_los:
		# query Accounset with LOS table to get the list of Accountsets associated to the looped LOS
		los_accountset_q = select([t_accounts_set_with_los.c.abi_sfa_account_set__c]).where(t_accounts_set_with_los.c.abi_sfa_los__c == los)
		los_accountsets = [ row['abi_sfa_account_set__c'] for row in conn.execute(los_accountset_q) ]
		los_accountsets = set(los_accountsets)
		log.debug('fetched {} account sets for {} los'.format(len(los_accountsets), los))

		required_accounts = set()
		
		for accountsets in los_accountsets:
			log.debug('processing account set #{}'.format(accountsets))
			# query accountset association to find the list of accounts associated to the Account Sets
			accounts_associated_q = select([t_accountset_assocn.c.account__c]).where(t_accountset_assocn.c.accountset__c == accountsets)
			accounts_associated = [ row['account__c'] for row in conn.execute(accounts_associated_q) ]
			required_accounts |= set(accounts_associated)

		# Query accounts from  "account with LOS" where Manual = false and los from loop -> call it "existing_los" 
		existing_accounts_q = select([t_accounts_with_los.c.abi_sfa_account__c]).\
							where(and_(t_accounts_with_los.c.abi_sfa_manual__c == False,\
									   t_accounts_with_los.c.abi_sfa_los__c == los))
		existing_accounts = set([ row['abi_sfa_account__c'] for row in conn.execute(existing_accounts_q) ])

		# required_accounts - existing_accounts = accounts_to_dessociate
		log.debug('{} existing_accounts; {} required_accounts while processing {} los'.\
				format(len(existing_accounts), len(required_accounts), los))
		accounts_to_dessociate = existing_accounts - required_accounts
		log.debug('going to dissociate {} accounts-los with {} los'.format(len(accounts_to_dessociate), los))

		# remove the line from account with los where  accountid in los_tobe_removed and los = los from the loop
		if len(accounts_to_dessociate) != 0:
			deassociate_los_q = delete(t_accounts_with_los).\
									where(and_(t_accounts_with_los.c.abi_sfa_los__c == los,\
											  t_accounts_with_los.c.abi_sfa_account__c.in_(accounts_to_dessociate)))
			result = conn.execute(deassociate_los_q)
			log.debug('{} records removed from accounts-with-los for {} los'.format(result.rowcount, los))

	# los dissociation ends here
	end = datetime.datetime.now()
	log.info('los dissociation for {} los is over at {};duration: {}'.format(len(all_los), end, end-start))


def update_heroku_processed_for_accountset(conn, table):
	"""
		Update ABI_SFA_Heroku_Job_Complete__c in ABI_SFA_Object_Configuration__c object
		
		param conn: database connection reference
		param table: abi_sfa_object_configuration__c object reference

		return None
	"""
	update_q = update(table).\
					where(table.c.abi_sfa_record_type_name__c == 'Batch Job Setup').\
						values(abi_sfa_heroku_job_complete__c=True, abi_sfa_hierarchy_job_complete__c=False)
	result = conn.execute(update_q)

	log.info('{} record been updated ABI_SFA_Object_Configuration__c object'.format(result.rowcount))


def remove_inactive_accountsetassociation_records(conn, table1, table2, table3):
	"""
		Remove inactive account set association records after processing of all active account set ids

		param conn: database connection reference
		param table1: accountsetassociation__c object reference
		param table2: account object reference
		param table3: accountset__c object reference

		return: number of inactive accounts removed
	"""
	# fetching inactive accounts from accountsetassociation__c object_namet
	j = table1.join(table3, table1.c.accountset__c == table3.c.sfid)
	query = select([table1.c.account__c, table1.c.sfid]).\
				select_from(j).where(table3.c.status__c == 'Inactive')
	
	inactive_accounts, inactive_sfids = set(), set()
	for row in conn.execute(query):
		inactive_accounts.add(row['account__c'])
		inactive_sfids.add(row['sfid'])

	# Delete from AccountSetAssociation where Accounset.Status = Inactive
	if len(inactive_sfids) != 0:
		delete_q = delete(table1).where(table1.c.sfid.in_(inactive_sfids))
		result = conn.execute(delete_q)
		rows_deleted = result.rowcount
		log.debug('{} inactive accountsetassociation__c records removed after processing active accountsets'.\
			format(rows_deleted))

	# Update account object for which the there are inactive accountsetassociation records
	if len(inactive_accounts) != 0:
		update_q = update(table2).where(table2.c.sfid.in_(inactive_accounts)).\
					values(abi_sfa_ismarkforaccountsetdeassociation__c=True)
		result = conn.execute(update_q)
		rows_updated = result.rowcount
		log.debug('{} inactive account records removed after processing active accountsets'.\
			format(rows_updated))


def is_hierarchy_job_complete_not_checked(conn, table):
	"""
		Check whether abi_sfa_hierarchy_job_complete__c is checked in abi_sfa_object_configuration__c object
		This will ensure that SFDC side processing over, indicating the heroku batch to run

		param conn: database connection reference
		param table: abi_sfa_object_configuration__c object reference

		return: Boolean
	"""
	try:
		hierarchy_job_complete_check_q = select([table.c.abi_sfa_hierarchy_job_complete__c]).\
											where(table.c.abi_sfa_record_type_name__c == 'Batch Job Setup')
		hierarchy_job_complete_check = conn.execute(hierarchy_job_complete_check_q).fetchone()['abi_sfa_hierarchy_job_complete__c']
		#log.info('abi_sfa_hierarchy_job_complete__c is : {}'.format(hierarchy_job_complete_check))

		return hierarchy_job_complete_check
	except Exception as e:
		log.info('Exception found as : {}'.format(e))
		return False

def update_accountset_flag_after_processing(conn, table, accountset_sfid):
	"""
		update ABI_SFA_Process_Assocn_Deassocn__c, MarkedforBatch__c in AccountSet__c object for currenltly processed accountset

		param conn: database connection reference
		param table: accountset__c object reference
		param accountset_sfid: accountset id for which accountset records to be updated
	"""
	update_q = update(table).\
					where(and_(table.c.sfid == accountset_sfid,\
						 or_(table.c.abi_sfa_process_assocn_deassocn__c == True, table.c.markedforbatch__c == True))).\
							values(abi_sfa_process_assocn_deassocn__c=False, markedforbatch__c=False)
	result = conn.execute(update_q)

	if result.rowcount != 0:
		log.debug('abi_sfa_process_assocn_deassocn__c, markedforbatch__cfileds have been updated for accountset #{}'.
			format(accountset_sfid))


def main():
	# add code to check if ABI_SFA_Hierarchy_Job_Complete__c is checked in abi_sfa_object_configuration__c object
	# if not checked sleep and wait for the flag to be checked 
	# if checked the process the batch forward
	while not is_hierarchy_job_complete_not_checked(connection, t_object_config):
		log.info('ABI_SFA_Hierarchy_Job_Complete__c flag in abi_sfa_object_configuration__c object is not checked yet.So sleeping......')
		time.sleep(25)

	log.info('Batch found ABI_SFA_Hierarchy_Job_Complete__c flag in abi_sfa_object_configuration__c object is checked.')
	log.info('Going to initiate processing of Accounts-set association and dissociation batch.')

	# Select ID from AccountSet__c where Status__c = Active and ABI_SFA_Fixed__c = False
	active_accountset_records = get_active_accountset_ids(connection, t_accountset)
	log.debug('received {} account set records to process in the batch'.format(len(active_accountset_records)))

	# before going to check in which mode batch needs to be run
	# get accountset ids present in redis 
	accountsets_in_redis = get_redis_accountset(r)

    # takign decision how the batch needs to be run; available options are:-
    # 1. run whole batch(run batch for all active accountsets)
    # 2. run batch for single provided accountset
    # 3. run batch from the last failed point(from the last accountset processed)
	if args['accountset'] != 'ALL':
		# run batch for single provided accountset
		active_accountset_records = [ row for row in active_accountset_records if row['id'] == args['accountset'] ]
		override_accountsets_with_new_ids(r, active_accountset_records, remove_old=True)
	elif len(accountsets_in_redis) > 1 and not args['flush']:
    	# run batch from the last failed point(from the last accountset processed)
		active_accountset_records = [ row for row in active_accountset_records if row['id'] in accountsets_in_redis ]
		active_accountset_records = sorted(active_accountset_records, key=lambda k: k['id'], reverse=True) 
	else:
		# run batch for all active accountsets
		override_accountsets_with_new_ids(r, active_accountset_records)
	
	log.info('accountsets to process:{};accountsets in redis:{}'.\
		format(len(active_accountset_records), len(get_redis_accountset(r))))

	# for each record received perform account set association and dissociation logic
	for count, record in enumerate(active_accountset_records):
		start = datetime.datetime.now()
		log.info('accountset association, dissociation and los association for #{} account set started;processing {}/{} accountsets'.\
				format(record['id'], count + 1, len(active_accountset_records)))
		log.info('record id {}'.format(record['id']))
		log.info('record criteria {}'.format(record['criteria']))
	    # Associate Accounts with Account Set
		log.info('going to associate accounts with {} accountset id and fetch criteria matching accounts'.format(record['id']))
		try:
			matched_accounts, asscociated_accs_count = associate_accounts_and_get_matched_accounts(connection, t_accountset_assocn, t_account, record)
			log.info('entered get_accountset_query_from_criteria')
		except Exception as e:
			log.info('Exception while processing accountset:{};exception is:{};Skipping....'.format(record['id'], str(e)))
			continue
		log.info('{} accounts associated with accountset id #{}'.format(asscociated_accs_count, record['id']))

		# De-associate unwanted accounts from Account Set
		log.info('going to dissociate accounts with {} accountset id and fetch removed accounts'.format(record['id']))
		dessoaciated_accounts = deassociate_accounts(connection, t_accountset_assocn, t_account, record, matched_accounts)
		log.info('{} accounts dissociated with accountset id #{}'.format(len(dessoaciated_accounts), record['id']))

		# Associate Accounts with LOS
		log.info('going to associate los with {} accountset id'.format(record['id']))
		associated_los_count = associate_los(connection, t_accounts_with_los, t_accounts_set_with_los, record, matched_accounts)
		log.info('{} LOS got associated against the account set id #{}'.format(associated_los_count, record['id']))

		log.info("Finished accountset association, deassociation and los association for #{} accountset;duration {}".\
				format(record['id'], datetime.datetime.now()-start))

		# update ABI_SFA_Process_Assocn_Deassocn__c, MarkedforBatch__c in AccountSet__c object
		# commenting these updates based on the discussion with the users
		#update_accountset_flag_after_processing(connection, t_accountset, record['id'])

		# remove current accountset from redis as this has been processed successfuly
		remove_accountset_id_from_redis(r, record['id'])
			
	# Delete from AccountSetAssociation where Account-set.Status = Inactive
	remove_inactive_accountsetassociation_records(connection, t_accountset_assocn, t_account, t_accountset)

	# De-associate Accounts with LOS
	deassociate_los(connection, t_los, t_accounts_with_los, t_accounts_set_with_los)

    # Here we are done with the batch processing
    # Perform some post batch processing operation 
    # check the account and accountset-association object are properly synced or not
    # before checking the herkou processed flag
	base_url, auth_key, app_name = get_base_url(), get_auth_key(), get_app_name()
	connection_id = get_connection_id(base_url, auth_key, app_name)
	tables = get_tables_to_sync(connection_id, base_url, auth_key)
	log.debug('base url: {}; auth key: {}; app_name: {}; connection_id: {};tables: {}'.\
			format(base_url, auth_key, app_name, connection_id, tables))

	for table, mapping_id in tables.items():
		while is_reload_pending(base_url, auth_key, mapping_id):
			log.info('Data from {} object is currently syncing with SFDC.Hence sleeping......'.format(table))
			time.sleep(25)
	
	# In the ABI_SFA_Object_Configuration__c mark the ABI_SFA_Heroku_Job_Complete__c flag to true
	log.info('batch processing over;account sets & los associated and dissociated.Going to update heroku processed flag.....')
	update_heroku_processed_for_accountset(connection, t_object_config)

	# closing db connection after completion of batch over
	log.info('Accounts-set association and dissociation batch processing over.Closing database connection')
	connection.close()

	
if __name__ == '__main__':
	main()
