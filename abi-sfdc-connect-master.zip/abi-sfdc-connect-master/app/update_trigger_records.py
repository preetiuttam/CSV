#!/usr/bin/env python


__author__ = 'niraj.kumar.panda'


import os
from logbook import Logger, INFO, NOTICE, DEBUG
from sqlalchemy import MetaData, create_engine, update
from sqlalchemy.sql import select, delete, and_, or_, text
from app.tools import *


# Fetching Heroku Environment variable values
DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
DEBUG = os.environ.get('DEBUG', False)


# Initiating global logging instance
log = Logger("UpdateTrigger")


def main():
	# Defining required variables
	metadata = MetaData()
	engine = create_engine(DATABASE_URL, echo=DEBUG) 
	connection = engine.connect()

	# getting required table's orm reference
	t_triger_log = get_table("_trigger_log", metadata, engine, SCHEMA)

	# declaring list of table names for which trigger failed records to try resyncing back to SFDC
	tables = ['account', 'accountset__c', 'accountsetassociation__c', 'abi_sfa_accounts_with_los__c']

	# UPDATE salesforce._trigger_log SET state = 'NEW' WHERE state = 'FAILED' AND table_name = 'contact';
	log.info('going to update failed _trigger_log records....')

	for table in tables:
		update_trigger_q = update(t_triger_log).\
							where(and_(t_triger_log.c.state == 'FAILED', t_triger_log.c.table_name == table)).\
							 values(state='NEW')
		result = connection.execute(update_trigger_q)
		log.debug('{} failed state {} records been updated with state = NEW'.format(result.rowcount, table))

	log.info('failed trigger records for {} heroku table been updated successfully'.format(len(tables)))
	connection.close()

if __name__ == '__main__':
	main()