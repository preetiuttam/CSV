__author__ = 'jan.van.den.broeck'
""" Runnable module to reload table so they are kept in sync

This module adds a runnable script to reload the SFDC tables where there is no isdeleted flag or lastmodifieddate
This script should run daily when there is no processing ongoing
"""

import requests
import os
import sys
import time
import json
from logging import getLogger
from logbook import Logger, DEBUG, INFO, WARNING, NOTICE
from app.exceptions import BadConfigException


TABLES_TO_RELOAD = ['Territory2', 'UserTerritory2Association', 'ObjectTerritory2Association']


# Configuring Logging
LOGLEVEL = os.environ.get('LOGLEVEL', 'INFO')
loglevels = {'DEBUG': DEBUG, 'INFO': INFO, 'NOTICE': NOTICE, 'WARNING': WARNING}
log = Logger("ReloadTables", level=loglevels[LOGLEVEL])


def get_base_url():
    """ Gets the base URL depending on the heroku region

    :return: string with the base domain name for the API (eg http://connect.heroku.com)
    """
    region = os.environ.get('HEROKUCONNECT_REGION', 'EU')

    if region == 'EU':
        return 'https://connect-eu.heroku.com'
    elif region == 'US':
        return 'https://connect.heroku.com'
    else:
        raise BadConfigException('HEROKUCONNECT_REGION environment variable is badly configured')


def get_auth_key():
    """ Returns the configured auth key (token) from the app config or raises exception if not set

    :return: string with the auth key
    """
    auth_key = os.environ.get('HEROKUCONNECT_TOKEN', None)
    if auth_key is None:
        raise BadConfigException('HEROKUCONNECT_TOKEN not configured')
    return auth_key


def get_app_name():
    app_name = os.environ.get('APP_NAME', None)
    if app_name is None:
        raise BadConfigException('APP_NAME not configured')
    return app_name


def get_connection_id(base_url, auth_key, app_name):
    """ Gets the connection ID based on the provided app name

    According to Step 4 of https://devcenter.heroku.com/articles/herokuconnect-api

    :param base_url: the base domain name for the API (eg http://connect.heroku.com)
    :param auth_key: string with the token for the user
    :param app_name: name of the current app
    :return: string with the unique id of the connection
    """
    global log
    log.info('Inside get_connection_id')
    url = '{}/api/v3/connections?app={}'.format(base_url, app_name)
    headers = {'Authorization': 'Bearer {}'.format(auth_key)}

    log.debug('Getting connection ID, url = {}'.format(url))

    r = requests.get(url, headers=headers)

    if r.status_code == 200:
        result = json.loads(r.text)
        log.debug('result= {}'.format(result))
        if result['count'] == 1:
            # the id column of the first result (because only one) of the results array.
            return result['results'][0]['id']
        else:
            raise BadConfigException('Multiple connections found while getting connection id for app'.format(app_name))
    else:
        raise ConnectionError('Could not get connection ID, exit with status code {}'.format(r.status_code))


def get_tables_to_reload(connection_id, base_url, auth_key):
    """ Returns the mappings (tables) that need to be reloaded

    :param connection_id: string with the unique id of the connection
    :param base_url: the base domain name for the API (eg http://connect.heroku.com)
    :param auth_key: string with the users auth key
    :return: a dict with table_name as key and the mapping id as value
    """

    # Example:
    # curl -H "Authorization: Bearer <token>" https://connect.heroku.com/api/v3/connections/<connection_id>?deep=true
    url = '{}/api/v3/connections/{}?deep=true'.format(base_url, connection_id)
    headers = {'Authorization': 'Bearer {}'.format(auth_key)}

    log.debug('Getting tables to reload, url = {}'.format(url))

    r = requests.get(url, headers=headers)

    if r.status_code != 200:
        raise ConnectionError('could not get the mappings')

    result = json.loads(r.text)
    mappings = result['mappings']
    tables = dict()

    for mapping in mappings:
        if mapping['object_name'] in TABLES_TO_RELOAD: #UPPERCASE
            # we don't do diff between counts[sf] and counts[db] because if it's deleted and recreated
            # differently in SFDC, it still needs to sync, so matching counts is not a guarantee
            tables[mapping['object_name']] = mapping['id']

    return tables


def reload(table, mapping_id, base_url, auth_key):
    """ Sends the reload command to reload a specific table

    :param table: Description of the table in human-readable format
    :param mapping_id: unique id of the table mapping
    :param base_url: the base domain name for the API (eg http://connect.heroku.com)
    :param auth_key: authentication token of the current user
    :return: None
    """
    # example
    # https://connect-eu.heroku.com/api/v3/mappings/<mapping_id>/actions/reload
    url = '{}/api/v3/mappings/{}/actions/reload'.format(base_url, mapping_id)
    headers = {'Authorization': 'Bearer {}'.format(auth_key),
               'Content-Type': 'application/json'}

    r = requests.post(url,headers=headers)
    log.info('response is {};response code is {}'.format(r.text, r.status_code))

    if r.status_code != 202:
        log.warn('Reloading for table {} failed with status code {}'.format(table, r.status_code))
        raise ConnectionError("Reload failed with status code {}".format(r.status_code))

    log.info('Table {} successfully reloaded'.format(table))
    
    return r


# method to check between 2 relaod method calls 
# to check the previous object been reloaded properly or not
def is_reload_pending(base_url, key, map_id):
    global log
    url = base_url + '/api/v3/mappings/' + map_id
    headers = {'Authorization': 'Bearer {}'.format(key)}
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        response = json.loads(response.text)
        if response['state'] != 'DATA_SYNCED':
            return True
        else:
            return False
    else:
        log.warn('Possible case of connection failure, while checking the status of mapping.Mapping id : {}'.format(map_id))
        #raise ConnectionError('Got connection error while collecting mapping reloading status.Mapping id : {}'.format(map_id))
        return False


if __name__ == '__main__':
    try:
        action = sys.argv[1]
    except IndexError as e:
        action = None

    log.info('Reloading Tables - For those tables where there is no isdeleted')
    log.info('action is : {}'.format(action))

    # Getting initial config
    log.debug('Getting base url, auth key & app name')
    base_url = get_base_url()
    auth_key = get_auth_key()
    app_name = get_app_name()

    log.debug('Getting connection ID')
    connection_id = get_connection_id(base_url, auth_key, app_name)
    
    log.debug('Getting tables to reload and their mapping IDs')
    tables = get_tables_to_reload(connection_id, base_url, auth_key)

    
    log.info('Starting reload for {} tables'.format(len(tables)))
    for table, mapping_id in tables.items():
        is_reloading = True
        log.info('going to reload {} mapping between salesforce->heroku postgres'.format(table))
        resp = reload(table, mapping_id, base_url, auth_key)
        log.debug('{} object is reloaded; response is : {}; response headers are : {}'.\
            format(table, resp, resp.headers))
        
        while is_reload_pending(base_url, auth_key, mapping_id):
            log.debug('Taking a nap as reload of {} mapping is going on(Salesforce -> Heroku)......'.format(table))
            time.sleep(25)
        log.info('Mapping {} has been reloaded successfully'.format(table))
        is_reloading = False

    log.info('Done with reloading for {} mapping/s'.format(tables))

    if action == 'unshare' and not is_reloading:
        log.info('Done with reload of all tables. Going to invoke unshare users batch')
        os.system('python app/fill_batch_unshare.py')
