class BadConfigException(Exception):
    """Exception raised for errors in the configuration of the tool

    """
    def __init__(self, value):
        self.value = value

class BadInputException(Exception):
    """Exception raised for errors in the input

    """
    def __init__(self, value):
        self.value = value

