#!/usr/bin/env python

__author__ = 'niraj.kumar.panda'


import os
import sys
import time
import redis
from sqlalchemy import MetaData, create_engine
from logbook import Logger, INFO, NOTICE, DEBUG
from sqlalchemy.sql import select, distinct, and_
from tools import get_table 


"""
    Usage:

    1. If running batch for all available users(production)

    python app/fill_batch_unshare.py

    2. If running batch for a particular user(dev/test)

    python app/fill_batch_unshare.py <18 digit user id>

    e.g:- python app/fill_batch_unshare.py 005240000050dSb
"""


log = Logger("FillBatchUnshare")
POOL = redis.ConnectionPool.from_url(os.environ.get("REDIS_URL", 'redis://localhost'))


try:
    flag = sys.argv[1]
except Exception as e:
    flag = None


def get_distinct_users(connection, table):
    query = select([table.c.userorgroupid]).\
            where(and_(table.c.rowcause == 'Territory_Access__c', table.c.userorgroupid.like('005%'))).distinct()
    
    return set([ row['userorgroupid'] for row in connection.execute(query) ])


def run_batch_unshares(metadata, engine):
    # declaring database specific configs
    DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
    SCHEMA = os.environ.get("HEROKUCONNECT_SCHEMA")
    DEBUG = os.environ.get('DEBUG', False)
    
    # connecting respective engines
    r = redis.Redis(connection_pool=POOL)
    conn = engine.connect()
    
    # getting required tables refferences
    t_account = get_table('account', metadata, engine, SCHEMA)
    t_territory2 = get_table("territory2", metadata, engine, SCHEMA)
    t_territory2model = get_table('territory2model', metadata, engine, SCHEMA)
    t_user_t_assn = get_table('userterritory2association', metadata, engine, SCHEMA)
    t_accountshare = get_table('accountshare', metadata, engine, SCHEMA)
    t_order_share = get_table('abi_sfa_order__share', metadata, engine, SCHEMA)
    t_visit_share = get_table('abi_sfa_visit__share', metadata, engine, SCHEMA)
    t_opportunity_share = get_table('abi_sfa_opportunity__share', metadata, engine, SCHEMA)

    # Add wholesaler accounts to redis
    # This will be added with the required share accounts while unsharing 
    get_wholesalers_q = select([t_account.c.sfid]).\
        where(t_account.c.abi_sfa_account_type__c == 'Wholesalers')
    wholesalers = [ row['sfid'] for row in conn.execute(get_wholesalers_q) ]
    log.info('Adding {} wholesaler accounts to Redis'.format(len(set(wholesalers))))
    r.sadd('Wholesalers', *set(wholesalers))

    # if flag is None all distinct users to be processed for unsharing
    # else a single user to be added to redis for unsharing(implemented for development)
    if flag is None:
        # Getting distinct users associated with territories.
        qry = select([t_accountshare.c.userorgroupid]).\
              where(and_(t_accountshare.c.rowcause == 'Manual',\
              t_accountshare.c.userorgroupid.like('005%'))).\
              distinct()
        accountshare_distinct_users = set([ row['userorgroupid'] for row in conn.execute(qry) ])
        visitshare_distinct_users = get_distinct_users(conn, t_visit_share)
        ordershare_distinct_users = get_distinct_users(conn, t_order_share)
        opportunityshare_distinct_users = get_distinct_users(conn, t_opportunity_share)

        distinct_users = accountshare_distinct_users.union(visitshare_distinct_users,\
                                       ordershare_distinct_users, opportunityshare_distinct_users)

        log.info('adding {} distinct users to redis'.format(len(distinct_users)))

        # Inserting all distinct users to redis for unsharing
        for user in distinct_users:
            r.sadd("Users", user)
    else:
        log.info('going to initiate unsharing for particular user;user specified: {}'.format(flag))
        r.sadd("Users", flag)


if __name__ == '__main__':
    DATABASE_URL = os.environ.get("DATABASE_URL","sqlite:///:memory:")
    metadata = MetaData()
    engine = create_engine(DATABASE_URL, echo=DEBUG)
    run_batch_unshares(metadata, engine)
