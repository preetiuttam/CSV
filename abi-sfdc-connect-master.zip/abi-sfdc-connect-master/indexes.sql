--objects--

-- abi_sfa_visit__c
CREATE INDEX abi_sfa_visit__c_idx_account
  ON salesforce.abi_sfa_visit__c
  USING btree
  (abi_sfa_account__c COLLATE pg_catalog."default" DESC NULLS LAST);
  
-- abi_sfa_activity_group__c
CREATE INDEX abi_sfa_activity_group__c_idx_account_md
  ON salesforce.abi_sfa_activity_group__c
  USING btree
  (abi_sfa_account_md__c COLLATE pg_catalog."default" DESC NULLS LAST);

-- abi_sfa_activity__c

CREATE INDEX abi_sfa_activity__c_idx_account_lp
  ON salesforce.abi_sfa_activity__c
  USING btree
  (abi_sfa_account_lp__c COLLATE pg_catalog."default" DESC NULLS LAST);

CREATE INDEX abi_sfa_activity__c_idx_account_kpi
  ON salesforce.abi_sfa_activity__c
  USING btree
  (abi_sfa_account_kpi__c COLLATE pg_catalog."default" DESC NULLS LAST);
  
CREATE INDEX abi_sfa_activity__c_idx_account_todo
  ON salesforce.abi_sfa_activity__c
  USING btree
  (abi_sfa_account_to_do__c COLLATE pg_catalog."default" DESC NULLS LAST);

-- abi_sfa_opportunity__c
CREATE INDEX abi_sfa_opportunity__c_idx_account
  ON salesforce.abi_sfa_opportunity__c
  USING btree
  (abi_sfa_account__c COLLATE pg_catalog."default");

-- abi_sfa_order__c
CREATE INDEX abi_sfa_order__c_idx_shipto
  ON salesforce.abi_sfa_order__c
  USING btree
  (abi_sfa_ship_to__c COLLATE pg_catalog."default");

-- abi_sfa_agreement__c
CREATE INDEX abi_sfa_agreement__c_idx_account
  ON salesforce.abi_sfa_agreement__c
  USING btree
  (abi_sfa_account__c COLLATE pg_catalog."default" DESC NULLS LAST);
  
-- abi_sfa_condition__c

CREATE INDEX abi_sfa_condition__c_idx_account
  ON salesforce.abi_sfa_condition__c
  USING btree
  (abi_sfa_related_account__c COLLATE pg_catalog."default" DESC NULLS LAST);

-- abi_sfa_account_relationships__c
CREATE INDEX abi_sfa_account_relationships__c_idx_shipto
  ON salesforce.abi_sfa_account_relationships__c
  USING btree
  (abi_sfa_ship_to__c COLLATE pg_catalog."default");

-- abi_sfa_suppliers__c
CREATE INDEX abi_sfa_suppliers__c_idx_account_s1
  ON salesforce.abi_sfa_suppliers__c
  USING btree
  (abi_sfa_account_s1__c COLLATE pg_catalog."default");

-- objectterritory2association --
CREATE INDEX objectterritory2association_idx_territory
  ON salesforce.objectterritory2association
  USING btree
  (territory2id COLLATE pg_catalog."default");

--SHARE--

-- abi_sfa_activity__share

CREATE INDEX abi_sfa_activity__share_idx_userorgroupid
  ON salesforce.abi_sfa_activity__share
  USING btree
  (userorgroupid COLLATE pg_catalog."default");

CREATE INDEX abi_sfa_activity__share_idx_parentid
  ON salesforce.abi_sfa_activity__share
  USING btree
  (parentid COLLATE pg_catalog."default");


-- abi_sfa_activity_group__share

CREATE INDEX abi_sfa_activity_group__share_idx_userorgroupid
  ON salesforce.abi_sfa_activity_group__share
  USING btree
  (userorgroupid COLLATE pg_catalog."default");

-- abi_sfa_agreement_share

CREATE INDEX abi_sfa_agreement__share_idx_userorgroupid
  ON salesforce.abi_sfa_agreement__share
  USING btree
  (userorgroupid COLLATE pg_catalog."default");

-- abi_sfa_condition_share

CREATE INDEX abi_sfa_condition__share_idx_userorgroupid
  ON salesforce.abi_sfa_condition__share
  USING btree
  (userorgroupid COLLATE pg_catalog."default");

CREATE INDEX CONCURRENTLY abi_sfa_condition__share_idx_parentid
  ON salesforce.abi_sfa_condition__share
  USING btree
  (parentid COLLATE pg_catalog."default");

-- abi_sfa_opportunity__share

CREATE INDEX abi_sfa_opportunity__share_idx_userorgroupid
  ON salesforce.abi_sfa_opportunity__share
  USING btree
  (userorgroupid COLLATE pg_catalog."default");

-- abi_sfa_visit__share

CREATE INDEX abi_sfa_visit__share_idx_userorgroupid
  ON salesforce.abi_sfa_visit__share
  USING btree
  (userorgroupid COLLATE pg_catalog."default");

-- abi_sfa_order__share

CREATE INDEX abi_sfa_order__share_idx_userorgroupid
  ON salesforce.abi_sfa_order__share
  USING btree
  (userorgroupid COLLATE pg_catalog."default");


-- accountshare
CREATE INDEX accountshare_idx_account
  ON salesforce.accountshare
  USING btree
  (accountid COLLATE pg_catalog."default");

CREATE INDEX accountshare_idx_userorgroupid
  ON salesforce.accountshare
  USING btree
  (userorgroupid COLLATE pg_catalog."default");

